<?php
include_once("includes/libreria.php");
include("includes/conf.php");

$eventoID = $_REQUEST['id'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Le Giare | ristorante :: news </title>
<base href="http://<?php echo $_SERVER['SERVER_NAME']?>" />
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="Author" content="Oddep - creactivetions Bari (Italy) - I-Factory web agency" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name-equiv="Content-Language" CONTENT="IT" />
<meta name="distribution" CONTENT="Global" />
<meta name="revisit-after" CONTENT="5 days" />
<!--<meta http-equiv="refresh" content="120">-->
<meta name="robots" CONTENT="FOLLOW,INDEX" />
<link rel="icon" href="" type="image/x-icon" />
<link rel="shortcut icon" href="" type="image/x-icon" />

<link rel="stylesheet" type="text/css" href="/style.css" />

<script type="text/javascript" src="/js/prototype.js"></script>
<script type="text/javascript" src="/js/scriptaculous.js?load=effects"></script>
<script type="text/javascript" src="/js/lightbox.js"></script>
<link rel="stylesheet" href="/lightbox.css" type="text/css" media="screen" />
<SCRIPT language=Javascript><!--
function mon(str) {
 window.status = str
}
function mout() {
 window.status = "Le Giare | ristorante"
}
//-->
</SCRIPT>
<?php include("analytics.php")?>
</head>
<body onLoad="mout();">
 <!-- start header -->
 <div id="header">
  <!--start logo -->
  <div id="logo">
   <a href="index.php"><img src="/entity/s_logo.gif" border="0" alt="torna alla home page" /></a>
  </div>
  <!-- end logo -->
  <!-- start foto header -->
  <div id="foto_header">
   <img src="/entity/foto_02.jpg" alt="Le Giare ristorante" />
  </div>
  <!-- end foto header -->
  <div class="clear"></div>
 </div>
 <!-- end header>
 <!-- start main -->
 <div id="main">
  <!-- start col sx -->
  <?php include("menuLeft.php");?>
  <!-- end col sx -->
  <!-- start col dx -->
  <div id="colDX">
   <h1 class="news"><span>News</span></h1>
   <div class="back"><a href="<?php echo $_SERVER['HTTP_REFERER']?>">indietro</a></div>
   <?php
$db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");

if(!$eventoID){
   $query = "SELECT * FROM Eventi WHERE TIPOLOGIA='2' ORDER BY DATA DESC";
   $result = mysql_query($query,$db);
   while ($riga = mysql_fetch_array($result)) {
            $path = "/news/".$riga['ID']."-".permalink(strtolower(stripslashes($riga['TITOLO']))).".html";
            echo '<div class="eventi-pre">
                <h2>'.stripslashes($riga['TITOLO']).'</h2>';
                echo '<em>'.$riga['DATA'].'</em> <a href="'.$path.'">continua...</a>';
            echo  '</div>';
   }
}else{
   $query = "SELECT * FROM Eventi WHERE ID='".$eventoID."' ORDER BY DATA DESC";
   $result = mysql_query($query,$db);
   while ($riga = mysql_fetch_array($result)) {
            $path = "/eventi/".$riga['ID']."-".permalink(strtolower(stripslashes($riga['TITOLO']))).".html";
            echo '<div class="eventi-pre">
                <h2>'.stripslashes($riga['TITOLO']).'</h2>';
                echo '<em>'.$riga['DATA'].'</em><br />';
                echo '<p>'.stripslashes($riga['DESCR']).'</p>';

            echo  '</div>';
   }


   $query = "SELECT * FROM Eventi_img WHERE eventoID='".$eventoID."' ORDER BY ordine ASC";
   $result = mysql_query($query,$db);
   if($result){
       echo '<ul id="img">';
       while ($riga = mysql_fetch_array($result)) {
                $path = "/eventi/".$riga['eventoID']."/s_".str_replace("_","",$riga['img']);
                $pathB = "/eventi/".$riga['eventoID']."/".str_replace("_","",$riga['img']);
                echo '<li><a href="'.$pathB.'" rel="lightbox[immagini]"><img src="'.$path.'"></a></li>';
       }
       echo '</ul>';
       echo '<div class="clear"></div>';
   }



}
mysql_close($db);


   ?>
  </div>
  <!-- end col dx -->
  <div class="clear"></div>
 </div>
 <!-- end main -->
 <!-- start footer -->
 <div id="footer">
  <div id="dati" style="text-align:center;"><span class="ris">Le Giare, ristorante</span> | Corso Alcide De Gasperi, 308 F - 70125 Bari (Italy)</div>
  <div id="menuBOTTOM" style="text-align:center;margin-top:10px;"><a href="index.php">le giare</a> | <a href="menu.php">men&ugrave;</a> | <a href="cartavini.php">carta dei vini</a> | <a href="dovesiamo.php">dove siamo</a> | <a href="contatti.php">contatti</a> | <a href="http://www.oddepisodes.com">OddEp * creactivetions</a> | <a href="http://www.i-factory.biz">I-Factory - web agency</a></div>
 </div>
 <!-- end footer -->
</body>
</html>

<?php
include_once("includes/libreria.php");
include("includes/conf.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Le Giare | ristorante :: men&ugrave; </title>
<!-- base href="http://www.legiareristorante.it" -->
<meta name="description" content=""> 
<meta name="keywords" content=""> 
<meta name="Author" content="Oddep - creactivetions Bari (Italy) - I-Factory web agency">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name-equiv="Content-Language" CONTENT="IT">
<meta name="distribution" CONTENT="Global">
<meta name="revisit-after" CONTENT="5 days">
<!--<meta http-equiv="refresh" content="120">-->
<meta name="robots" CONTENT="FOLLOW,INDEX">
<link rel="icon" href="" type="image/x-icon" />
<link rel="shortcut icon" href="" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="style.css">
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/scriptaculous.js?load=effects"></script>
<script type="text/javascript" src="js/lightbox.js"></script>
<link rel="stylesheet" href="lightbox.css" type="text/css" media="screen" />
<SCRIPT language=Javascript><!--
function mon(str) {
 window.status = str
}
function mout() {
 window.status = "Le Giare | ristorante"
}
//-->
</SCRIPT>
<?php include("analytics.php")?>
</head>
<body onLoad="mout();">
 <!-- start header -->
 <div id="header">
  <!--start logo -->
  <div id="logo">
   <a href="index.php"><img src="entity/s_logo.gif" border="0" alt="torna alla home page"></a>
  </div>
  <!-- end logo -->
  <!-- start foto header -->
  <div id="foto_header">
   <img src="entity/foto_02.jpg" alt="Le Giare ristorante" />
  </div>
  <!-- end foto header -->
  <div class="clear"></div>
 </div>
 <!-- end header>
 <!-- start main -->
 <div id="main">
  <!-- start col sx -->
  <?php include("menuLeft.php");?>
  <!-- end col sx -->
  <!-- start col dx -->
  <div id="colDX">
   <h1 class="menu"><span>Menu</span></h1>
    <p style="text-align:right; margin:20px 0px;"><? echo stripslashes(getDati("Testi","valore",4)); ?></p>
    
    <h2>Antipasti</h2>
    <p class="portata">Tagliata di seppia arrostita, salsa di pane casereccio, capperi e melanzana confit</p>
    <p class="prezzo"></p>
    <div class="clear"></div>
    <br />

    <p class="portata">Frittella di ricotta limonata con fumetto di baccal&agrave e petali di pomodori</p>
    <p class="prezzo"></p>
    <div class="clear"></div>
    <br />
    
    <p class="portata">Agnello al punto rosa, mandorle tostate, costine e maionese di bietola</p>
    <p class="prezzo"></p>
    <div class="clear"></div>
    <br />
    
    <p class="portata">Tritato di maialino,patate gialle e viola e salsa di fichi</p>
    <p class="prezzo"></p>
    <div class="clear"></div>
    <br />
    
    <h2>Primi Piatti</h2>
    <p class="portata">Spaghettoni con asparagi passati e non passati, burrata e bottarga di tonno</p>
    <p class="prezzo"></p>
    <div class="clear"></div>
    <br />
    
    <p class="portata">Raviolone di fagiolini e lardone, salsa di gamberi rossi e spuma all'erba lippa</p>
    <p class="prezzo"></p>
    <div class="clear"></div>
    <br />
    
    <p class="portata">Fettuccelle di Kamut integrale condite con succo di canasta e stracotto di carni bianche</p>
    <p class="prezzo"></p>
    <div class="clear"></div>
    <br />
    
    <p class="portata">Risotto carnaroli mantecato al formaggio di fossa, miele di tarassaco e marinato di manzetta al pepe</p>
    <p class="prezzo"></p>
    <div class="clear"></div>
    <br />
    
    <h2>Secondi Piatti</h2>
    <p class="portata">Cosciotto di coniglio con porri in agrodolce e bavarese di fegatini</p>
    <p class="prezzo"></p>
    <div class="clear"></div>
    <br />
    
    <p class="portata">Petto d'anatra di barberia lievemente affumicato, patate cristallo e sughetto d'arrosto al moscato</p>
    <p class="prezzo"></p>
    <div class="clear"></div>
    <br />
    
    <p class="portata">Filetto di baccal&agrave con cipollotto sudato in padella e polenta di ceci fritta</p>
    <p class="prezzo"></p>
    <div class="clear"></div>
    <br />
    
    <p class="portata">Rombo in crosta di pistacchi di Bronte, salsa di patate violette e gocce di zafferano</p>
    <p class="prezzo"></p>
    <div class="clear"></div>
    <br />
   
  <?
//   $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
//   if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
//    	$query = "SELECT * FROM Menu_categorie ORDER BY N_ORD ASC";
//    	$result = mysql_query($query,$db);
//    	while ($riga = mysql_fetch_array($result)) {
//    		$query2 = "SELECT * FROM Menu WHERE CATEGORIA = '".$riga[ID]."' ORDER BY ORDINE ASC";
//    		$result2 = mysql_query($query2,$db);
//    		$num_prodotti = mysql_num_rows($result2);
//    		if ($num_prodotti!=0){
//    			echo "<h2>".$riga[NOME]."</h2>";
//    			while ($riga2 = mysql_fetch_array($result2)) {
//    				echo "<p class='portata'>".ucfirst(stripslashes(strip_tags($riga2[DESCR],'<br><span>')))."</p>";
//    				echo "<p class='prezzo'>euro ".$riga2[PREZZO]."</p>";
//                                echo '<div class="clear"></div>';
//                                echo '<br />';
//    			}
//    		}
//        }
   ?>
  </div>
  <!-- end col dx -->
  <div class="clear"></div>
 </div>
 <!-- end main -->
 <!-- start footer -->
 <div id="footer">
  <div id="dati" style="text-align:center;"><span class="ris">Le Giare, ristorante</span> | Corso Alcide De Gasperi, 308 F - 70125 Bari (Italy)</div>
  <div id="menuBOTTOM" style="text-align:center;margin-top:10px;"><a href="index.php">le giare</a> | <a href="menu.php">men&ugrave;</a> | <a href="cartavini.php">carta dei vini</a> | <a href="dovesiamo.php">dove siamo</a> | <a href="contatti.php">contatti</a> | <a href="http://www.oddepisodes.com">OddEp * creactivetions</a> | <a href="http://www.i-factory.biz">I-Factory - web agency</a></div>
 </div>
 <!-- end footer -->
</BODY>
</HTML>

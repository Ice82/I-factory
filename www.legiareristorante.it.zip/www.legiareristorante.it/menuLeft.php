  <div id="colSX">
   <!-- start menu -->
    <div id="menuLEFT">
    <ul id="menu">
     <li><a href="/index.php">le giare</a></li>
     <li><a href="/menu.php">men&ugrave;</a></li>
     <li><a href="/cartavini.php">carta dei vini</a></li>
     <li><a href="/galleria-fotografica.php">galleria</a></li>
     <li><a href="/ns.php">news</a></li>
     <li><a href="/eventi.php">eventi</a></li>
     <li><a href="/dicono-noi.php">dicono di noi</a></li>
     <li><a href="/link-amici.php">link amici</a></li>
     <li><a href="/dovesiamo.php">dove siamo</a></li>
     <li><a href="/contatti.php">contatti</a></li>
    </ul>
   </div>
   <!-- end menu -->

   <?php
   if(strip_tags(getDati("Testi","valore",1))){?>
   <div class="boxSX">
    <h3>INFO</h3>
    <p style="text-align: left;"><span class="ris"><? echo stripslashes(getDati("Testi","valore",1)); ?></span></p>
   </div>
    <?php }?>

   <div class="boxSX">
    <h3>Per prenotazioni</h3>
    <p><span class="ris">tel</span> (+39) 080 501 13 83</p>
    <p><span class="ris">mail</span> info@legiareristorante.it</p>
   </div>

    <div class="boxSX">
        <iframe src="//www.facebook.com/plugins/likebox.php?href=https%3A%2F%2Fwww.facebook.com%2Flegiareristorante&amp;width=181&amp;height=315&amp;show_faces=true&amp;colorscheme=light&amp;stream=false&amp;border_color&amp;header=true&amp;appId=175440733635" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:181px; height:315px;" allowTransparency="true"></iframe>
    <!--<p><a href="<? echo getDati("Testi","valore",2); ?>" target="_blank"><img src="/entity/facebook.jpg" alt="seguici su facebook" /><span class="fb">seguici su facebook</span></a></p>-->
    </div>

   
   

   <div class="boxSX">
    <h3>Orari apertura | chiusura </h3>
    <p><span class="ris">pranzo</span> 12,45 - 15,00</p>
    <p><span class="ris">cena</span> 19,45 - 23,00</p>
   </div>
   <!-- start per prenotazioni -->
   <!-- start foto -->
   <?php include("fotoSX.php")?>
   <!-- end foto -->
  </div>



<?php
session_start();
include_once("includes/libreria.php");
include("includes/conf.php");
include('includes/class.phpmailer.php');
include('captcha/securimage.php');


    function CheckCaptcha($val, $error, $name = 'captcha')
    {

        // verifica codice
        $img = new Securimage();
        $valid = $img->check(trim($val));
        if(!$valid)
            return false;
        else
	        return true;
    }


if ($_POST['pulsante'] == "invia"){
	
	if ( !isset($_POST['nome']) || ($_POST['nome'] == "")) $errori['nome'] = '<span class="error">Inserisci nome</strong>';
	if ( !isset($_POST['cognome']) || ($_POST['cognome'] == "")) $errori['cognome'] = '<span class="error">Inserisci cognome</strong>';
	if ( !isset($_POST['email']) || ($_POST['email'] == "")) $errori['email'] = '<span class="error">Inserisci indirizzo e-mail</strong>';
	if ( !isset($_POST['telefono']) || ($_POST['telefono'] == "")) $errori['telefono'] = '<span class="error">Inserisci nome</strong>';
	
	$codice = CheckCaptcha($_REQUEST['code'],    "Errore captcha");
	if (($codice == true) && (count($errori)<1) ){
		$mail = new PHPMailer(); 
		$mail->From = "info@legiareristorante.it"; 
		$mail->FromName = "Le Giare Ristorante"; 
		$mail->Subject = "Contatti dal sito Le Giare Ristorante"; 
		//$mail->Body = "Testo del messaggio"; 
		$body = $mail->getFile("mail_registrati.php");
		$body = eregi_replace("[\]",'',$body);
        $body = eregi_replace("{nome}", $_POST['nome'],$body);
		$body = eregi_replace("{cognome}", $_POST['cognome'],$body);
        $body = eregi_replace("{indirizzo}", $_POST['indirizzo'],$body);
  		$body = eregi_replace("{email}", $_POST['email'],$body);
  		$body = eregi_replace("{telefono}", $_POST['telefono'],$body);
  		$body = eregi_replace("{messaggio}", $_POST['messaggio'],$body);
		$mail->Body = $body;
		$mail->AddAddress("info@legiareristorante.it","info@legiareristorante.it"); 
		if($mail->Send()){ 
    		$result['result']=true; 
		} else{
			$result['result']=false;
			$result['errors'][]='Invio FALLITO';
			$result['errors'][]=$mail->ErrorInfo; 
		}
		$mail->ClearAddresses();
		$mail->AddAddress("postmaster@i-factory.biz", "postmaster@i-factory.biz");
  		$mail->Send();
  		header("location: contatti.php?msg=ok");
	}else{
		$errori['codice'] = '<span class="error">Errore nell\'inserimento del codice</strong>';
	}
	
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Le Giare | ristorante :: contatti </title>
<meta name="description" content="Ristorante Le giare, contatami" /> 
<meta name="keywords" content="le giare, ristorante bari, ristorante le giare" /> 
<meta name="Author" content="Oddep - creactivetions Bari (Italy) - I-Factory web agency" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" type="text/css" href="style.css" />

<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/scriptaculous.js?load=effects"></script>
<script type="text/javascript" src="js/lightbox.js"></script>
<link rel="stylesheet" href="lightbox.css" type="text/css" media="screen" />

<style>
.error {font-size: 12px; color:#e00; font-weight: bold }
</style>
<?php include("analytics.php")?>
</head>
<body>
 <!-- start header -->
 <div id="header">
  <!--start logo -->
  <div id="logo">
   <a href="index.php"><img src="entity/s_logo.gif" border="0" alt="torna alla home page" /></a>
  </div>
  <!-- end logo -->
  <!-- start foto header -->
  <div id="foto_header">
   <img src="entity/foto_02.jpg" alt="Le Giare ristorante" />
  </div>
  <!-- end foto header -->
  <div class="clear"></div>
 </div>
 <!-- end header -->
 <!-- start main -->
 <div id="main">
  <!-- start col sx -->
    <?php include("menuLeft.php");?>
  <!-- end col sx -->
  <!-- start col dx -->
  <div id="colDX">
   <h1 class="contatti"><span>Contatti</span></h1>
<p>Per ricevere maggiori informazioni, su orari, eventi, sulla disponibilit&agrave; della sala, non esitare a contattarci telefonicamente o tramite il modulo che segue, 
facendo attenzione a non tralasciare campi come <span class="ris">(*) Email</span> o <span class="ris">(*) Telefono</span> senza i quali ci risulterebbe poi difficile ricontattarti.</p>

<?php if ($_GET['msg'] == "ok")
	echo '<p style="margin-top: 10px; margin-bottom: 10px; font-size: 13px; font-weight: bold; color: #aaa">Richiesta inviata correttamente! Grazie...</p>';
?>


      <form name="modulo" action="contatti.php" method="post" style="margin-top:10px;">
      <label class="label"><span class="ris">(*)</span> Nome</label> <?php echo $errori['nome']?><br />
      <input type="text" name="nome" class="form_contatti" size="40" /><br />
      <label class="label"><span class="ris">(*)</span> Cognome</label> <?php echo $errori['cognome']?><br />
      <input type="text" name="cognome" class="form_contatti" size="40" /><br />
      <label class="label">Indirizzo | Citt&agrave; | Cap</label><br />
      <input type="text" name="indirizzo" class="form_contatti" size="40" /><br />
      <label class="label"><span class="ris">(*)</span> Email</label> <?php echo $errori['email']?><br />
      <input type="text" name="email" class="form_contatti" size="40" /><br />
      <label class="label"><span class="ris">(*)</span> Telefono</label> <?php echo $errori['telefono']?><br />
   	  <input type="text" name="telefono" class="form_contatti" size="40" /><br />
      <label class="label">Messaggio</label><br />
      <textarea name="messaggio" class="form_contatti" cols="40" rows="10"></textarea><br />
      <p><i>Informativa e prestazione del consenso al trattamento dei dati ex artt. 13 e 23 del d.lgs. n. 196/2003.</i></p>
   <p>La informiamo ai sensi dell'art. 13 del d.lgs. 30 giugno 2003, n. 196 (recante il "Codice in materia di protezione dei dati personali" nel prosieguo, 
   per brevit&agrave;, il "Codice"), che i dati personali forniti in sede di adesione al servizio di mailing list saranno raccolti e registrati da Fiorentinoinbari Srl 
   - quale Titolare del trattamento - su supporti cartacei, elettronici e/o informatici e/o telematici protetti e trattati con modalit&agrave; idonee a garantire la 
   sicurezza e la riservatezza nel rispetto delle disposizioni del Codice. La informiamo che i dati fornitici verranno utilizzati per finalit&agrave; strettamente connesse 
   e strumentali alla esecuzione del servizio di mailing list. Il conferimento dei dati personali per tale finalit&agrave; &egrave; indispensabile per la erogazione del predetto servizio.
   Previo suo consenso, i dati conferiti potranno essere utilizzati da Fiorentinoinbari Srl  per finalit&agrave; promozionali, pubblicitarie e di marketing quali l'invio di materiale pubblicitario,
   promozionale ed informativo su prodotti e servizi, nonch&egrave; per analisi statistiche dirette a rilevare il grado di soddisfazione dei servizi/prodotti offerti.
   Potr&agrave; esercitare i diritti previsti dall'art. 7 e seg. del Codice (tra cui, accesso, correzione, cancellazione, opposizione al trattamento etc.) rivolgendosi al Titolare del trattamento dei dati Fiorentinoinbari Srl,
   con sede legale in Bari (Italy) in via dei Bersaglieri 3.</p>
   <p>Ai sensi degli articoli 13 e 23 del d.lgs.196/2003, dichiaro di aver preso atto dell'informativa relativa al trattamento dei miei dati e liberamente presto il consenso<br />
   - al trattamento dei miei dati personali, da parte del Titolare della Fiorentinoinbari Srl, per le finalit&agrave; promozionali, pubblicitarie e di marketing specificate nell'informativa.</p>
   <span class="ris"><input type="radio" name="privacy" value="accetto" CHECKED />accetto &nbsp;&nbsp; <input type="radio" name="privacy" value="non accetto" />non accetto</span><br />
	<label class="label">Codice di verifica</label> <?php echo $errori['codice']?>
	<?php 
	$SID = md5(uniqid(time()));
	?>
	<table cellpadding="1" cellspacing="1" border="0"><tr>
	 <td><img src="captcha/securimage_show.php?sid=<?php echo $SID ?>" /></td>
	 <td><input name="code" type="text" maxlength="10" class="form_contatti" style="width: 100px" /></td>
	</tr></table>
      <input type="submit" class="form_contatti_btn" name="pulsante" value="invia" alt="invia richiesta informazioni" />
   </form>
  </div>
  <!-- end col dx -->
  <div class="clear"></div>
 </div>
 <!-- end main -->
 <!-- start footer -->
 <div id="footer">
  <div id="dati" style="text-align:center;"><span class="ris">Le Giare, ristorante</span> | Corso Alcide De Gasperi, 308 F - 70125 Bari (Italy)</div>
  <div id="menuBOTTOM" style="text-align:center;margin-top:10px;"><a href="index.php">le giare</a> | <a href="menu.php">men&ugrave;</a> | <a href="cartavini.php">carta dei vini</a> | <a href="dovesiamo.php">dove siamo</a> | <a href="contatti.php">contatti</a> | <a href="http://www.oddepisodes.com">OddEp * creactivetions</a> | <a href="http://www.i-factory.biz">I-Factory - web agency</a></div>
 </div>
 <!-- end footer -->
</body>
</html>

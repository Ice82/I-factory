<?php

include_once("includes/libreria.php");
include("includes/conf.php");

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Le Giare | ristorante :: carta dei vini </title>
<!-- base href="http://www.legiareristorante.it" -->
<meta name="description" content=""> 
<meta name="keywords" content=""> 
<meta name="Author" content="Oddep - creactivetions Bari (Italy) - I-Factory web agency">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name-equiv="Content-Language" CONTENT="IT">
<meta name="distribution" CONTENT="Global">
<meta name="revisit-after" CONTENT="5 days">
<!--<meta http-equiv="refresh" content="120">-->
<meta name="robots" CONTENT="FOLLOW,INDEX">
<link rel="icon" href="" type="image/x-icon" />
<link rel="shortcut icon" href="" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="style.css" />
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/scriptaculous.js?load=effects"></script>
<script type="text/javascript" src="js/lightbox.js"></script>
<link rel="stylesheet" href="lightbox.css" type="text/css" media="screen" />

<script type="text/javascript" src="/js/jquery.1.4.2.min.js"></script>
<script>
$(document).ready(function(){

$('.vini_link a').click(function() {
        //$('.vini').hide();
        var id = $(this).attr('id');
        $('#vini'+id).toggle();
        return false;
    });


})
</script>
<style>
.regione { color: #000; font-size: 20px; }
</style>
<?php include("analytics.php")?>
</head>
<body onLoad="mout();">
 <!-- start header -->
 <div id="header">
  <!--start logo -->
  <div id="logo">
   <a href="index.php"><img src="entity/s_logo.gif" border="0" alt="torna alla home page" /></a>
  </div>
  <!-- end logo -->
  <!-- start foto header -->
  <div id="foto_header">
   <img src="entity/foto_02.jpg" alt="Le Giare ristorante" />
  </div>
  <!-- end foto header -->
  <div class="clear"></div>
 </div>
 <!-- end header>
 <!-- start main -->
 <div id="main">
  <!-- start col sx -->
  <?php include("menuLeft.php");?>
  <!-- end col sx -->
  <!-- start col dx -->
  <div id="colDX">
   <div class="italia"><span>scegli la tua regione</span><br /><img src="/entity/italia.jpg" usemap="#italia" border="0" /></div>
   <h1 class="cartadeivini"><span>Carta dei vini</span></h1>
   <div class="clear"></div>



  <?
   if($_GET['regione']){
       $regione_nome = getDati("Regioni", "NOME", $_GET['regione']);
       echo '<h1 class="regione">'.$regione_nome.'</h1>';
       $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
       if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
            if($_GET['categoria'])
                $query = "SELECT * FROM Vini_categorie WHERE ID = '".$_GET['categoria']."' ORDER BY N_ORD ASC";
            else
                $query = "SELECT * FROM Vini_categorie ORDER BY N_ORD ASC";
            $result = mysql_query($query,$db);
            while ($riga = mysql_fetch_array($result)) {
                    $query2 = "SELECT v.* , c.NOME AS nomeCantina
                                    FROM Vini AS v
                                    LEFT JOIN Cantine AS c ON (c.ID=v.ID_CANTINA)
                                    WHERE v.CATEGORIA = '".$riga[ID]."' AND v.regioneID='".$_GET['regione']."' ORDER BY v.ordine ASC";
                    $result2 = mysql_query($query2,$db);
                    $num_prodotti = mysql_num_rows($result2);
                    if ($num_prodotti!=0){
                            $num = $num+1;
                            echo '<h2 class="vini_link"><a href="#" id="_'.$riga[ID].'">'.stripslashes($riga[NOME]).'</a></h2>';
                            if($_GET['categoria'])
                                echo '<div id="vini_'.$riga[ID].'" class="vini" style="display: block;">';
                            else
                                echo '<div id="vini_'.$riga[ID].'" class="vini">';
                            while ($riga2 = mysql_fetch_array($result2)) {
                                    /*echo '<pre>';
                                    print_r($riga2);
                                    echo '<pre>';
                                    */
                                    echo "<p class='portata vinis'><strong>".ucfirst(stripslashes($riga2['NOME']))."</strong> - ".stripslashes($riga2['cantina_nome'])."<br />";
                                    if ($riga2[UVAGGIO]!='') {echo ucfirst($riga2[UVAGGIO])."<br />";}
                                    //if ($riga2[DESCR]!='') {echo "Info:".ucfirst($riga2[DESCR])."<br />";}
                                    //if ($riga2[GRADO]!='') {echo "Grado: ".$riga2[GRADO]." %<br />";}
                                    //if ($riga2[CAPACITA]!='') {echo "Capacit&agrave; ".$riga2[CAPACITA]." litri<br />";}
                                    
                                    echo '</p>';
                                    echo "<p class='prezzo'>";
                                    if ($riga2[PREZZO_CALICE]!='') {echo "Calice: <i>euro ".$riga2[PREZZO_CALICE]."</i><br />";}
                                    if ($riga2[PREZZO_PUBBL]!='') {echo "Bottiglia: <i>euro ".$riga2[PREZZO_PUBBL]."</i><br />";}
                                    echo '</p>';
                                    echo '<div class="clear"></div><br />';
                            }
                            echo '</div>';
                    }
            }
            if($num==0)
                echo '<p>Nessun vino per la regione selezionata</p>';
   }


   if(!($_GET['regione'])){
       $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
       if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
            $query = "SELECT * FROM Vini_categorie ORDER BY N_ORD ASC";
            $result = mysql_query($query,$db);
            while ($riga = mysql_fetch_array($result)) {
                    $query2 = "SELECT r.ID , r.NOME AS regione
                                    FROM Vini AS v
                                    LEFT JOIN Cantine AS c ON (c.ID=v.ID_CANTINA)
                                    JOIN Regioni AS r ON (r.ID=v.regioneID)
                                    WHERE v.CATEGORIA = '".$riga[ID]."' GROUP BY r.ID ORDER BY r.nome ASC";
                    $result2 = mysql_query($query2,$db);
                    $num_prodotti = mysql_num_rows($result2);
                    if ($num_prodotti>0){
                            echo '<h2 class="vini_link"><a href="#" id="_'.$riga[ID].'">'.stripslashes($riga[NOME]).'</a></h2>';
                            echo '<div id="vini_'.$riga[ID].'" class="vini">';
                            while ($riga2 = mysql_fetch_array($result2)) {
                                    /*echo '<pre>';
                                    print_r($riga2);
                                    echo '<pre>';
                                    */
                                    echo '<p class="portata vinis"><a href="cartavini.php?regione='.$riga2[ID].'&categoria='.$riga['ID'].'">'.ucfirst($riga2['regione']).' &raquo;</a><br />';
                                    //if ($riga2[UVAGGIO]!='') {echo "Uvaggio: ".ucfirst($riga2[UVAGGIO])."<br />";}
                                    //if ($riga2[DESCR]!='') {echo "Info:".ucfirst($riga2[DESCR])."<br />";}
                                    //if ($riga2[GRADO]!='') {echo "Grado: ".$riga2[GRADO]." %<br />";}
                                    //if ($riga2[CAPACITA]!='') {echo "Capacit&agrave; ".$riga2[CAPACITA]." litri<br />";}
                                    if ($riga2['nomeCantina']){
                                            echo "Cantina: <i>".ucfirst(getDati("Cantine","NOME",$riga2[ID_CANTINA]))." - ".ucfirst(getDati("Cantine","DESCR",$riga2[ID_CANTINA]))."</i><br />";
                                    }
                                    echo '</p>';
                                    echo "<p class='prezzo'>";
                                    if ($riga2[PREZZO_CALICE]!='') {echo "Calice: <i>euro ".$riga2[PREZZO_CALICE]."</i><br />";}
                                    if ($riga2[PREZZO_PUBBL]!='') {echo "Bottiglia: <i>euro ".$riga2[PREZZO_PUBBL]."</i><br />";}
                                    echo '</p>';
                                    echo '<div class="clear"></div><br />';
                            }
                            echo '</div>';
                    }
            }
       
   }
   ?>
  </div>
  <!-- end col dx -->
  <div class="clear"></div>
 </div>
 <map NAME="italia">
<AREA shape="POLY" coords="105,13,96,24,96,25,95,23,97,24,96,28,98,32,99,34,99,37,104,36,105,34,106,37,109,38,113,38,117,38,117,36,119,40,122,40,121,35,117,31,120,27,116,23,120,21,106,13" href="cartavini.php?regione=6" alt="Friuli Venezia Giulia" >
<AREA SHAPE=POLY COORDS="70,32,71,36,69,39,69,45,72,44,73,49,81,53,87,54,90,53,92,56,95,56,97,54,94,51,93,49,95,41,101,41,107,39,108,37,104,35,101,35,99,31,96,27,100,22,104,16,105,13,99,12,98,12,89,18,87,18,89,22,86,27,83,28,82,27,77,32,73,32,69,31" href="cartavini.php?regione=20" alt="Veneto" >
<AREA SHAPE=POLY href="cartavini.php?regione=17" title="Trentino Alto Adige" COORDS="63,11,68,17,67,23,67,29,67,35,72,33,79,32,82,27,85,26,91,23,87,19,89,16,98,13,99,11,95,6,96,3,93,0,89,2,87,3,82,2,77,4,73,4,71,2,69,2,66,3,66,8,64,9,64,12">
<AREA SHAPE=POLY href="cartavini.php?regione=9" title="Lombardia" COORDS="37,18,33,24,32,26,35,32,36,38,34,40,31,40,36,46,38,46,42,53,42,57,47,50,48,46,49,46,56,46,57,49,60,49,65,50,68,51,73,51,75,51,76,50,70,45,71,43,67,42,69,38,70,34,70,32,68,32,68,27,68,19,68,14,62,10,59,15,54,16,52,16,52,15,50,12,48,14,48,17,46,20,43,21,41,23,39,24,39,22,39,20,38,19">
<AREA SHAPE=POLY href="cartavini.php?regione=12" title="Piemonte" COORDS="36,21,36,17,33,13,30,12,26,17,26,21,23,21,24,28,23,32,19,34,14,36,12,35,8,36,5,39,0,40,2,43,3,49,3,57,7,65,12,63,15,65,21,65,24,63,24,59,26,57,27,57,30,60,36,59,39,57,43,57,43,55,42,52,38,46,36,45,32,43,31,40,34,38,37,37,35,32,32,27,36,23,38,20,37,20">
<AREA SHAPE=POLY href="cartavini.php?regione=19" title="Valle d'Aosta" COORDS="23,23,19,22,15,24,11,24,10,22,7,22,8,26,8,29,8,32,8,35,12,35,17,35,22,33,23,30,22,25,23,22">
<AREA SHAPE=POLY href="cartavini.php?regione=8" title="Liguria" COORDS="19,75,22,71,24,69,28,64,31,61,35,61,39,63,43,67,47,69,53,74,57,74,56,71,52,67,50,66,48,62,46,61,43,59,40,58,36,58,34,59,31,60,30,60,26,59,23,58,23,61,21,62,21,65,17,66,12,69,12,71,13,73,17,74">
<AREA href="cartavini.php?regione=5" SHAPE=POLY title="Emilia Romagna" COORDS="80,74,68,72,64,68,56,66,53,68,50,67,46,62,43,58,43,55,47,50,48,46,50,45,55,46,58,48,66,50,72,50,77,50,79,52,83,52,91,53,92,55,93,58,93,65,94,71,98,74,98,77,97,79,92,78,89,78,89,81,85,78,82,76,83,73,76,73,72,72">
<AREA href="cartavini.php?regione=16" SHAPE=POLY title="Toscana" COORDS="56,76,59,81,57,90,60,97,62,105,67,109,71,113,76,114,82,110,82,105,81,103,85,98,86,94,91,90,91,86,92,81,89,78,85,76,83,75,81,74,76,74,71,73,67,71,63,68,61,66,54,65,53,66,57,70,56,74,56,76,60,79">
<AREA SHAPE=POLY COORDS="85,109,84,106,83,103,81,104,81,109,77,111,76,114,79,117,85,129,100,141,104,142,110,143,117,141,120,137,120,132,117,131,112,128,106,124,102,123,103,116,105,112,105,109,100,109,97,114,93,114,89,111,87,109,85,106,84,105" href="cartavini.php?regione=7" alt="Lazio">
<AREA href="cartavini.php?regione=10" SHAPE=POLY title="Marche" COORDS="117,104,117,99,116,92,111,89,104,81,100,77,101,78,98,78,95,78,93,78,89,78,89,79,90,82,93,82,92,85,92,87,95,89,96,91,98,93,101,95,102,100,102,102,104,104,105,107,107,108,113,106,116,102">
<AREA href="cartavini.php?regione=18" SHAPE=POLY title="Umbria" COORDS="91,88,86,88,88,90,89,93,88,95,87,96,84,102,83,104,83,107,85,109,89,109,90,112,91,115,95,113,96,111,102,109,105,109,109,110,108,107,105,105,103,102,102,99,102,94,101,92,98,89,94,86,91,88">
<AREA href="cartavini.php?regione=1" SHAPE=POLY title="Abruzzo" COORDS="120,111,116,104,108,107,105,110,105,113,105,115,105,119,105,121,105,124,110,127,112,129,114,131,117,131,119,129,122,126,127,128,132,124,130,121,124,114,120,111">
<AREA href="cartavini.php?regione=4" SHAPE=POLY title="Campania" COORDS="115,144,117,151,117,152,116,154,123,155,125,155,124,157,129,159,131,159,134,162,135,165,134,168,137,168,140,172,143,172,146,172,149,168,149,165,145,158,145,152,148,149,148,146,142,143,137,139,135,136,128,140,122,137,118,137,117,141,115,143">
<AREA href="cartavini.php?regione=11" SHAPE=POLY title="Molise" COORDS="137,127,132,124,126,126,122,126,121,130,119,130,118,134,119,137,123,137,126,137,130,137,133,138,137,136,137,134,139,133,139,127,136,126">
<AREA href="cartavini.php?regione=13" SHAPE=POLY title="Puglia" COORDS="158,130,157,134,155,134,154,135,155,140,163,143,169,148,173,150,174,150,176,150,179,152,187,154,193,160,194,167,198,171,197,175,196,178,194,178,189,177,187,174,186,169,183,167,176,167,171,164,169,164,165,157,163,156,158,152,156,151,151,146,144,146,143,143,141,142,137,139,134,136,137,135,140,131,139,128,143,126,148,126,154,126,157,127,158,131">
<AREA href="cartavini.php?regione=2" SHAPE=POLY title="Basilicata" COORDS="147,171,152,174,155,174,157,175,161,171,162,170,166,170,168,163,168,160,166,156,162,155,160,155,160,153,157,151,153,148,151,146,146,146,148,150,145,150,143,151,146,153,144,156,144,158,148,162,147,165,148,169,147,171">
<AREA href="cartavini.php?regione=3" SHAPE=POLY title="Calabria" COORDS="162,172,165,171,163,175,161,178,166,181,170,185,173,187,173,191,173,196,173,199,171,202,166,202,165,205,163,206,161,209,157,214,155,218,154,221,150,222,148,223,147,220,147,216,147,212,149,210,150,206,153,202,155,201,155,195,153,189,151,184,150,179,149,175,148,173,151,175,154,175,156,175,158,175,161,173,162,172">
<AREA href="cartavini.php?regione=15" SHAPE=POLY title="Sicilia" COORDS="144,215,142,220,140,224,138,230,137,232,135,233,136,240,138,244,138,245,135,249,135,252,133,252,129,251,124,250,122,247,118,243,112,241,107,238,101,236,97,231,92,228,89,226,86,223,87,219,91,215,94,215,97,215,101,214,107,217,110,218,118,218,122,219,128,219,132,216,137,216,141,216,144,214">
<AREA href="cartavini.php?regione=14" SHAPE=POLY title="Sardegna" COORDS="42,153,42,160,40,164,38,174,36,182,36,188,36,190,30,186,28,185,26,189,23,191,22,194,19,191,16,188,14,184,12,179,16,174,18,172,17,167,17,164,19,160,18,152,14,149,14,144,14,142,17,145,24,146,32,142,31,137,33,137,40,139,41,141,42,150,43,156,43,158">
</map>
 <!-- end main -->
 <!-- start footer -->
 <div id="footer">
  <div id="dati" style="text-align:center;"><span class="ris">Le Giare, ristorante</span> | Corso Alcide De Gasperi, 308 F - 70125 Bari (Italy)</div>
  <div id="menuBOTTOM" style="text-align:center;margin-top:10px;"><a href="index.php">le giare</a> | <a href="menu.php">men&ugrave;</a> | <a href="cartavini.php">carta dei vini</a> | <a href="dovesiamo.php">dove siamo</a> | <a href="contatti.php">contatti</a> | <a href="http://www.oddepisodes.com">OddEp * creactivetions</a> | <a href="http://www.i-factory.biz">I-Factory - web agency</a></div>
 </div>
 <!-- end footer -->
</body>
</html>

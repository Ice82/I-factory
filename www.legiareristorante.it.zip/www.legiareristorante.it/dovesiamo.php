<?php
include_once("includes/libreria.php");
include("includes/conf.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Le Giare | ristorante :: dove siamo </title>
<!-- base href="http://www.legiareristorante.it" -->
<meta name="description" content=""> 
<meta name="keywords" content=""> 
<meta name="Author" content="Oddep - creactivetions Bari (Italy) - I-Factory web agency">
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name-equiv="Content-Language" CONTENT="IT">
<meta name="distribution" CONTENT="Global">
<meta name="revisit-after" CONTENT="5 days">
<!--<meta http-equiv="refresh" content="120">-->
<meta name="robots" CONTENT="FOLLOW,INDEX">
<link rel="icon" href="" type="image/x-icon" />
<link rel="shortcut icon" href="" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="style.css">
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/scriptaculous.js?load=effects"></script>
<script type="text/javascript" src="js/lightbox.js"></script>
<link rel="stylesheet" href="lightbox.css" type="text/css" media="screen" />
<SCRIPT language=Javascript><!--
function mon(str) {
 window.status = str
}
function mout() {
 window.status = "Le Giare | ristorante"
}
//-->
</SCRIPT>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
<script type="text/javascript">
  function initialize() {
    var myLatlng = new google.maps.LatLng(41.09540,16.870890);
    var myOptions = {
      zoom: 13,
      center: myLatlng,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    var map = new google.maps.Map(document.getElementById("map"), myOptions);

    var marker = new google.maps.Marker({
        position: myLatlng,
        map: map,
        title:"Le Giare Ristorante"
    });
  }
</script>
<?php include("analytics.php")?>
</head>
<BODY onLoad="initialize();mout();" onunload="GUnload()">
 <!-- start header -->
 <div id="header">
  <!--start logo -->
  <div id="logo">
   <a href="index.php"><img src="entity/s_logo.gif" border="0" alt="torna alla home page"></a>
  </div>
  <!-- end logo -->
  <!-- start foto header -->
  <div id="foto_header">
   <img src="entity/foto_02.jpg" alt="Le Giare ristorante">
  </div>
  <!-- end foto header -->
  <div class="clear"></div>
 </div>
 <!-- end header>
 <!-- start main -->
 <div id="main">
  <!-- start col sx -->
  <?php include("menuLeft.php");?>
  <!-- end col sx -->
  <!-- start col dx -->
  <div id="colDX">
   <h1 class="dovesiamo"><span>Dove Siamo</span></h1>
   <p><span class="ris">Le Giare, ristorante</span></p>
   <p>Corso Alcide De Gasperi, 308 F - 70125 Bari (Italy)</p><br><br>
   <div id="map" style="width:520px;height:250px;"></div><br>
   
  </div>
  <!-- end col dx -->
  <div class="clear"></div>
 </div>
 <!-- end main -->
 <!-- start footer -->
 <div id="footer">
  <div id="dati" style="text-align:center;"><span class="ris">Le Giare, ristorante</span> | Corso Alcide De Gasperi, 308 F - 70125 Bari (Italy)</div>
  <div id="menuBOTTOM" style="text-align:center;margin-top:10px;"><a href="index.php">le giare</a> | <a href="menu.php">men&ugrave;</a> | <a href="cartavini.php">carta dei vini</a> | <a href="dovesiamo.php">dove siamo</a> | <a href="contatti.php">contatti</a> | <a href="http://www.oddepisodes.com">OddEp * creactivetions</a> | <a href="http://www.i-factory.biz">I-Factory - web agency</a></div>
 </div>
 <!-- end footer -->
</BODY>
</HTML>

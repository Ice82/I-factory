<?php
session_start();
include_once("../includes/libreria.php");
include("../includes/conf.php");
If (($_SESSION['IsUserGood'] == False) || (!isset($_SESSION['user']))) {
	header("location: ../tool.php?ctrl=2"); 
}

if ($_POST[pulsante]=="Aggiorna") {
 $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
 if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
 $query = "UPDATE Eventi SET TITOLO ='".addslashes(strip_tags($_POST['titolo']))."' WHERE ID ='".$_POST['id']."'";
 mysql_query($query,$db);
 $query = "UPDATE Eventi SET DESCR ='".addslashes($_POST['descrizione'])."' WHERE ID ='".$_POST['id']."'";
 mysql_query($query,$db);
 $query = "UPDATE Eventi SET DATA ='".$_POST['data']."' WHERE ID ='".$_POST['id']."'";
 mysql_query($query,$db);
 $query = "UPDATE Eventi SET ORARIO ='".$_POST['orario']."' WHERE ID ='".$_POST['id']."'";
 mysql_query($query,$db);
 $query = "UPDATE Eventi SET TIPOLOGIA ='".$_POST['tipologia']."' WHERE ID ='".$_POST['id']."'";
 mysql_query($query,$db);
 $query = "UPDATE Eventi SET HOME ='".$_POST['home']."' WHERE ID ='".$_POST['id']."'";
 mysql_query($query,$db);
 mysql_close($db);
 header("location: eventi_mod.php");
}

?>
<html>
<head>
<title><?=$nome_dominio;?> :: Pannello di Controllo</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="Author" content="I-Factory di Nicola Claudio Cellamare">
<META NAME="robots" CONTENT="index, follow"> <!-- (Robot commands: All, None, Index, No Index, Follow, No Follow) -->
<META NAME="revisit-after" CONTENT="2 days">
<META NAME="distribution" CONTENT="global">
<META NAME="rating" CONTENT="general">
<META NAME="Content-Language" CONTENT="italiano">
<LINK href="../includes/tool.css" rel=STYLESHEET type=text/css>
<SCRIPT language=Javascript><!-- 
function mon(str) {
 window.status = str
}
function mout() {
 window.status = "Pannello di Controllo :: <?=$nome_dominio;?>"
}

//-->
</SCRIPT>

</head>
<BODY BGCOLOR="#FFFFFF" LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
<DIV class='testo' id='tool' style='margin:4px;'>


<?
if ($_POST[pulsante] == "") {
?>
<table cellpadding=0 cellspacing=4 border=0 class="tableTool"><tr>
<th class="label">Tipologia</th>
<th class="label">Titolo</th>
<th class="label">Data</th></tr>
<?
 $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
 if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
 $query = "SELECT * FROM Eventi ORDER BY ID DESC";
 $result = mysql_query($query,$db);
 //$num_prodotti = mysql_num_rows($result);
 //echo $num_prodotti;
 while ($riga = mysql_fetch_array($result)) {
     switch($riga['TIPOLOGIA']){
         case 1:
             $tipologia = "Eventi";
             break;
         case 2:
             $tipologia = "News";
             break;
         case 3:
             $tipologia = "Dicono di noi";
             break;
     }


  echo "<FORM action='eventi_mod.php' method='post'><tr>";
  echo "<td class='testo'>".$tipologia."<input type='hidden' name='ID' value='".$riga['ID']."'></td>";
  echo "<td class='testo'>".stripslashes($riga['TITOLO'])."</td>";
  echo "<td class='testo'>".stripslashes($riga['DATA'])."</td>";
  echo "<td class='noborder'><input type='submit' name='pulsante' value='Modifica' class='form'><input type='submit' name='pulsante' value='Elimina' class='form'></td></tr></FORM>";
 }
 mysql_close($db);
 ?>
</table>
<?
}
?>

<?
if ($_POST[pulsante]=="Modifica") {
?> 
<form name="Modifica" action="eventi_mod.php" method="post" enctype="multipart/form-data">
<span class="label">Tipologia</span><br>
<?php
$tipologia = getDati("Eventi","TIPOLOGIA",$_POST[ID]);
echo '<select name ="tipologia" class="form">';
    echo '<option value="">Scegli...</option>';
    if($tipologia == 1) echo '<option value="1" selected>Eventi</option>'; else echo '<option value="1">Eventi</option>';
    if($tipologia == 2) echo '<option value="2" selected>News</option>'; else echo '<option value="2">News</option>';
echo '</select>';
?>
<br>
<span class="label">Titolo</span><br>
<input type="text" name="titolo" class="form" size="20" value="<? echo stripslashes(getDati("Eventi","TITOLO",$_POST[ID])); ?>"><br>
<span class="label">Descrizione</span><br>
<textarea style="width: 400px; height: 100px;" id="descrizione" name="descrizione"><? echo stripslashes(getDati("Eventi","DESCR",$_POST[ID]));?></textarea>
<script type="text/javascript" src="../js/nicEdit.js"></script>
<script type="text/javascript">
new nicEditor({iconsPath : '../js/nicEditorIcons.gif'}).panelInstance('descrizione');
</script><br />
<span class="label">Data (es. gg/mm/aaaa)</span><br>
<input type="text" name="data" class="form" size="20" value="<? echo getDati("Eventi","DATA",$_POST[ID]); ?>"><br>
<span class="label">Orario (es. alle ore 20.15)</span><br>
<input type="text" name="orario" class="form" size="20" value="<? echo getDati("Eventi","ORARIO",$_POST[ID]); ?>"><br>
<?php
$home = getDati("Eventi","HOME",$_POST[ID]);
if($home == 0) $cNO = "checked"; else $cSI = "checked";
?>
<span class="label">In Homepage</span><br>
<input type="radio" name="home" class="form" value="0" <?php echo $cNO?> /> NO  <input type="radio" name="home" class="form" value="1" <?php echo $cSI?> /> SI <br><br />

<input type="hidden" name="id" value="<? echo $_POST[ID];?>"><input type="submit" name="pulsante" class="form" value="Aggiorna">
<input type="button" name="pulsante" class="form" value="Torna indietro" onClick="history.back();">
</form>
<? 
}
if ($_POST[pulsante]=="Elimina") {
 $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
 if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
 $query = "DELETE FROM Eventi WHERE ID ='".$_POST['ID']."'";
 mysql_query($query,$db);
 mysql_close($db);
 header("location: eventi_mod.php");
}
?>
</DIV>
</BODY>
</HTML>
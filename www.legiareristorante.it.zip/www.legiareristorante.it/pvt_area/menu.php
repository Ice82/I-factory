<!--------Start Menu---------->
<div class="mainDiv" state="0">
<div class="topItem" classOut="topItem" classOver="topItemOver">
<table cellpadding=0 cellspacing=0 border=0><tr>
 <td width=10 bgcolor="<?php echo $colore_pannello;?>"></td>
 <td bgcolor="#aaaaaa" style='padding-right:3px;' height=20 width=160 class="topItem"><a href="../tool.php?ctrl=3" class="topItem">Log Out</a></td>
</tr></table></div>
</div></div><!--------End Menu---------->
<!--------Start Menu---------->
<div class="mainDiv" state="0">
<div class="topItem" classOut="topItem" classOver="topItemOver">
<table cellpadding=0 cellspacing=0 border=0><tr>
 <td width=10 bgcolor="<?php echo $colore_pannello;?>"></td>
 <td bgcolor="#aaaaaa" style='padding-right:3px;' height=20 width=160 class="topItem"><a href="index.php" class="topItem">Home Page</a></td>
</tr></table></div>
</div></div><!--------End Menu---------->

<!--------Start Menu---------->
<div class="mainDiv" state="0">
<div class="topItem" classOut="topItem" classOver="topItemOver" onMouseOver="Init(this);">
<table cellpadding=0 cellspacing=0 border=0><tr>
 <td width=10 bgcolor="<?=$colore_pannello;?>"></td>
 <td bgcolor="#aaaaaa" style='padding-left:3px;padding-right:3px;' height=20 width=160 class="topItem">Cantine</td>
</tr></table></div>
<div class="dropMenu"><div class="subMenu" state="0">
	<span class="subItem" classOut="subItem" classOver="subItemOver"><a href="cantine_add.php">:: Inserisci / Modifica</a></span><BR>
</div></div></div><!--------End Menu---------->
<!--------Start Menu---------->
<div class="mainDiv" state="0">
<div class="topItem" classOut="topItem" classOver="topItemOver" onMouseOver="Init(this);">
<table cellpadding=0 cellspacing=0 border=0><tr>
 <td width=10 bgcolor="<?=$colore_pannello;?>"></td>
 <td bgcolor="#aaaaaa" style='padding-left:3px;padding-right:3px;' height=20 width=160 class="topItem">Vini</td>
</tr></table></div>
<div class="dropMenu"><div class="subMenu" state="0">
	<span class="subItem" classOut="subItem" classOver="subItemOver"><a href="vini_add.php">:: Inserisci</a></span><BR>
	<span class="subItem" classOut="subItem" classOver="subItemOver"><a href="vini_mod.php">:: Modifica</a></span><BR>
	<span class="subItem" classOut="subItem" classOver="subItemOver"><a href="catvini_add.php">:: Inser / Modif Categorie</a></span><BR>
</div></div></div><!--------End Menu---------->
<!--------Start Menu---------->
<div class="mainDiv" state="0">
<div class="topItem" classOut="topItem" classOver="topItemOver" onMouseOver="Init(this);">
<table cellpadding=0 cellspacing=0 border=0><tr>
 <td width=10 bgcolor="<?=$colore_pannello;?>"></td>
 <td bgcolor="#aaaaaa" style='padding-left:3px;padding-right:3px;' height=20 width=160 class="topItem">Categorie Menu</td>
</tr></table></div>
<div class="dropMenu"><div class="subMenu" state="0">
	<span class="subItem" classOut="subItem" classOver="subItemOver"><a href="catmenu_add.php">:: Inserisci / Modifica</a></span><BR>
</div></div></div><!--------End Menu---------->
<!--------Start Menu---------->
<div class="mainDiv" state="0">
<div class="topItem" classOut="topItem" classOver="topItemOver" onMouseOver="Init(this);">
<table cellpadding=0 cellspacing=0 border=0><tr>
 <td width=10 bgcolor="<?=$colore_pannello;?>"></td>
 <td bgcolor="#aaaaaa" style='padding-left:3px;padding-right:3px;' height=20 width=160 class="topItem">Menu</td>
</tr></table></div>
<div class="dropMenu"><div class="subMenu" state="0">
	<span class="subItem" classOut="subItem" classOver="subItemOver"><a href="menu_add.php">:: Inserisci Portate</a></span><BR>
	<span class="subItem" classOut="subItem" classOver="subItemOver"><a href="menu_mod.php">:: Modifica Portate</a></span><BR>
 </div></div></div><!--------End Menu---------->
<!--------Start Menu---------->
<div class="mainDiv" state="0">
<div class="topItem" classOut="topItem" classOver="topItemOver" onMouseOver="Init(this);">
<table cellpadding=0 cellspacing=0 border=0><tr>
 <td width=10 bgcolor="<?=$colore_pannello;?>"></td>
 <td bgcolor="#aaaaaa" style='padding-left:3px;padding-right:3px;' height=20 width=160 class="topItem">Partner</td>
</tr></table></div>
<div class="dropMenu"><div class="subMenu" state="0">
	<span class="subItem" classOut="subItem" classOver="subItemOver"><a href="partner_add.php">:: Inserisci</a></span><BR>
	<span class="subItem" classOut="subItem" classOver="subItemOver"><a href="partner_mod.php">:: Modifica</a></span><BR>
 </div></div></div><!--------End Menu---------->
 <!--------Start Menu---------->
<div class="mainDiv" state="0">
<div class="topItem" classOut="topItem" classOver="topItemOver" onMouseOver="Init(this);">
<table cellpadding=0 cellspacing=0 border=0><tr>
 <td width=10 bgcolor="<?=$colore_pannello;?>"></td>
 <td bgcolor="#aaaaaa" style='padding-left:3px;padding-right:3px;' height=20 width=160 class="topItem">Eventi</td>
</tr></table></div>
<div class="dropMenu"><div class="subMenu" state="0">
	<span class="subItem" classOut="subItem" classOver="subItemOver"><a href="eventi_add.php">:: Inserisci / Modifica</a></span><BR>
        <span class="subItem" classOut="subItem" classOver="subItemOver"><a href="eventi_img_add.php">:: Immagini > Inserisci</a></span><BR>
        <span class="subItem" classOut="subItem" classOver="subItemOver"><a href="eventi_img_mod.php">:: Immagini > Modifica</a></span><BR>
</div></div></div><!--------End Menu---------->
 <!--------Start Menu---------->
<div class="mainDiv" state="0">
<div class="topItem" classOut="topItem" classOver="topItemOver" onMouseOver="Init(this);">
<table cellpadding=0 cellspacing=0 border=0><tr>
 <td width=10 bgcolor="<?=$colore_pannello;?>"></td>
 <td bgcolor="#aaaaaa" style='padding-left:3px;padding-right:3px;' height=20 width=160 class="topItem">Testi</td>
</tr></table></div>
<div class="dropMenu"><div class="subMenu" state="0">
	<span class="subItem" classOut="subItem" classOver="subItemOver"><a href="testi.php">:: Modifica</a></span><BR>
</div></div></div><!--------End Menu---------->
<!--------Start Menu---------->
<div class="mainDiv" state="0">
<div class="topItem" classOut="topItem" classOver="topItemOver" onMouseOver="Init(this);">
<table cellpadding=0 cellspacing=0 border=0><tr>
 <td width=10 bgcolor="<?=$colore_pannello;?>"></td>
 <td bgcolor="#aaaaaa" style='padding-left:3px;padding-right:3px;' height=20 width=160 class="topItem">Galleria Fotografica</td>
</tr></table></div>
<div class="dropMenu"><div class="subMenu" state="0">
        <span class="subItem" classOut="subItem" classOver="subItemOver"><a href="gall_img_add.php">:: Immagini > Inserisci</a></span><BR>
        <span class="subItem" classOut="subItem" classOver="subItemOver"><a href="gall_img_mod.php">:: Immagini > Modifica</a></span><BR>
</div></div></div><!--------End Menu---------->

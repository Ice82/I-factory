<?php
session_start();
include_once("../includes/libreria.php");
include("../includes/conf.php");
If (($_SESSION['IsUserGood'] == False) || (!isset($_SESSION['user']))) {
	header("location: ../tool.php?ctrl=2"); 
}

if ($_POST[pulsante]=="Aggiorna") {
 $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
 if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
 $query = "UPDATE Vini_categorie SET NOME ='".addslashes(strip_tags($_POST['nome']))."' WHERE ID ='".$_POST['id']."'";
 mysql_query($query,$db);
 mysql_close($db);
 header("location: catvini_mod.php");
}
if ($_POST[pulsante]=="Ordina") {
 $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
 if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
 $query = "UPDATE Vini_categorie SET N_ORD ='".$_POST['n_ord']."' WHERE ID ='".$_POST['ID']."'";
 mysql_query($query,$db);
 mysql_close($db);
 header("location: catvini_mod.php");
}
?>
<html>
<head>
<title><?=$nome_dominio;?> :: Pannello di Controllo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="Author" content="I-Factory di Nicola Claudio Cellamare">
<META NAME="robots" CONTENT="index, follow"> <!-- (Robot commands: All, None, Index, No Index, Follow, No Follow) -->
<META NAME="revisit-after" CONTENT="2 days">
<META NAME="distribution" CONTENT="global">
<META NAME="rating" CONTENT="general">
<META NAME="Content-Language" CONTENT="italiano">
<LINK href="../includes/tool.css" rel=STYLESHEET type=text/css>
<SCRIPT language=Javascript><!-- 
function mon(str) {
 window.status = str
}
function mout() {
 window.status = "Pannello di Controllo :: <?=$nome_dominio;?>"
}

//-->
</SCRIPT>

</head>
<BODY BGCOLOR="#FFFFFF" LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0>
<DIV class='testo' id='tool' style='margin:4px;'>


<?
if ($_POST[pulsante] == "") {
?>
<table cellpadding=0 cellspacing=4 border=0 class="tableTool"><tr>

<th class="label">Nome</th>
<th class="label">N.Ord.</th></tr>
<?
 $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
 if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
 $query = "SELECT * FROM Vini_categorie ORDER BY N_ORD ASC";
 $result = mysql_query($query,$db);
 while ($riga = mysql_fetch_array($result)) {
  echo "<tr><FORM action='catvini_mod.php' method='post'>";
  echo "<input type='hidden' name='ID' value='".$riga['ID']."'>";
  echo "<td class='testo'>".stripslashes($riga['NOME'])."</td>";
  echo "<td class='testo'><input type='text' name='n_ord' class='form' size='5' value='".$riga['N_ORD']."'></td>";
  echo "<td class='noborder'><input type='submit' name='pulsante' value='Ordina' class='form'><input type='submit' name='pulsante' value='Modifica' class='form'><input type='submit' name='pulsante' value='Elimina' class='form'></td></FORM></tr>";
 }
 mysql_close($db);
 ?>
</table>
<?
}
?>

<?
if ($_POST[pulsante]=="Modifica") {
?> 
<FORM name="Modifica" action="catvini_mod.php" method="post" enctype="multipart/form-data">
<span class="label">Nome</span><br>
<input type="text" name="nome" class="form" size="20" value="<? echo stripslashes(getDati("Vini_categorie","NOME",$_POST[ID])); ?>"><br>
<input type="hidden" name="id" value="<? echo $_POST[ID];?>"><input type="submit" name="pulsante" class="form" value="Aggiorna">
<input type="button" name="pulsante" class="form" value="Torna indietro" onClick="history.back();">
</FORM>
<? 
}


if ($_POST[pulsante]=="Elimina") {
 $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
 if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
 $query = "DELETE FROM Vini_categorie WHERE ID ='".$_POST['ID']."'";
 mysql_query($query,$db);
 mysql_close($db);
 header("location: catvini_mod.php");
}
?>
</DIV>
</BODY>
</HTML>
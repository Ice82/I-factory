<?php
session_start();
include_once("../includes/libreria.php");
include("../includes/conf.php");
include_once("../includes/class.php");
If (($_SESSION['IsUserGood'] == False) || (!isset($_SESSION['user']))) {
	header("location: ../tool.php?ctrl=2"); 
}

if ($_POST[pulsante]=="Inserisci") {
 $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
 if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
 $query = "INSERT INTO Vini (CATEGORIA,ID_CANTINA,NOME,UVAGGIO,GRADO,CAPACITA,DESCR,PREZZO_PUBBL,PREZZO_LEGIARE,PREZZO_CALICE,prezzo_asp,ordine,regioneID,cantina_nome) values (
                            '".$_POST['tipo']."',
                            '".$_POST['cantina']."',
                            '".addslashes(strip_tags($_POST['nome']))."',
                            '".addslashes(strip_tags($_POST['uvaggio']))."',
                            '".addslashes(strip_tags($_POST['grado']))."',
                            '".addslashes(strip_tags($_POST['capacita']))."',
                            '".addslashes(strip_tags($_POST['descrizione']))."',
                            '".addslashes(strip_tags($_POST['prezzo_pubbl']))."',
                            '".addslashes(strip_tags($_POST['prezzo_legiare']))."',
                            '".addslashes(strip_tags($_POST['prezzo_calice']))."',
                            '".str_replace(strip_tags($_POST['prezzo_asp']))."',
                            '".addslashes(strip_tags($_POST['ordine']))."',
                            '".addslashes(strip_tags($_POST['regione']))."',
                            '".addslashes($_POST['cantina_nome'])."')";
 if (mysql_query($query,$db)) {
 	$id_vino = mysql_insert_id();
 	$dir = "../public/vini/".$id_vino;
 	mkdir($dir, 0777);
 	chmod($dir,0777); //permessi per poterci sovrascrivere/scaricare
 	if ($_FILES['image']['name'] != ""){
 		//echo $dir."<br>";
  		$classe = IMAGE;
  		$Sample = new $classe;
  		$Sample->Upload($dir,$_FILES['image']['name'], $_FILES['image']['tmp_name']);
  		$nome_file = str_replace(" ", "", $_FILES['image']['name']);
		$nome_file = str_replace("_", "", $nome_file);
  		$query = "UPDATE Vini SET IMAGE='".$nome_file."' WHERE ID ='".$id_vino."'";
 		mysql_query($query,$db);	
  		}
  	if ($_FILES['etichetta']['name'] != ""){
 		//echo $dir."<br>";
  		$classe = IMAGE;
  		$Sample = new $classe;
  		$Sample->Upload($dir,$_FILES['etichetta']['name'], $_FILES['etichetta']['tmp_name']);
  		$nome_file = str_replace(" ", "", $_FILES['image']['name']);
		$nome_file = str_replace("_", "", $nome_file);
  		$query = "UPDATE Vini SET ETICHETTA='".$nome_file."' WHERE ID ='".$id_vino."'";
 		mysql_query($query,$db);	
  		}
 	//echo "<script>alert('Vino Inserito Correttamente')</script>";
 	
 	}
 else {
 	echo "<script>alert('Errore nell'inserimento del Vino')</script>";
 }
 mysql_close($db);
}

?>
<html>
<head>
<title><?=$nome_dominio;?> :: Pannello di Controllo</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="Author" content="I-Factory di Nicola Claudio Cellamare">
<META NAME="robots" CONTENT="index, follow"> <!-- (Robot commands: All, None, Index, No Index, Follow, No Follow) -->
<META NAME="revisit-after" CONTENT="2 days">
<META NAME="distribution" CONTENT="global">
<META NAME="rating" CONTENT="general">
<META NAME="Content-Language" CONTENT="italiano">
<LINK href="../includes/tool.css" rel=STYLESHEET type=text/css>
<SCRIPT language=Javascript><!-- 
function mon(str) {
 window.status = str
}
function mout() {
 window.status = "Pannello di Controllo :: <?=$nome_dominio;?>"
}

//-->
</SCRIPT>

</head>
<BODY BGCOLOR="#FFFFFF" LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0 onLoad="mout();">
<TABLE CELLPADDING=0 CELLSPACING=1 BORDER=0 WIDTH=100% HEIGHT=100%><TR>
<TD WIDTH=1% HEIGHT=99% VALIGN=TOP style="border-right:solid 1px <?php echo $colore_pannello;?>">
<!-- TABELLA TOP START -->
 <table cellpadding=0 cellspacing=0 border=0 height='60' width='176' style="border-bottom:solid 1px <?php echo $colore_pannello;?>"><tr>
  <td width=180 align=center><a href="index.php"><img src="entity/<?=$logo;?>" border=0 Alt="<?=$nome_dominio;?> :: Home Pannello di controllo"></a></td>
</tr></table>
<!-- TABELLA TOP END -->
<!-- MENU' START -->
 <table cellpadding=0 cellspacing=0 border=0 width=170><tr>
 <td><!-- MENU' START --><script language="JavaScript" type="text/javascript" src="../includes/menu.js"></script>
  <?php include("menu.php")?>
    <DIV id="liveclock" class="credit" style='color:#aaaaaa;margin-left:8px;margin-top:10px;font-size:9px;'><!-- OROLOGIO - START --><script type='text/javascript' src="../includes/orologio.js"></script><!-- OROLOGIO - END --></DIV></td>
 </tr></table>
<!-- MENU' END -->
</TD>
 <TD WIDTH=99% HEIGHT="99%" VALIGN=TOP>
<table cellpadding=0 cellspacing=0 border=0 width=100% height=100%><tr>
<td height=1%><!-- TOP BODY START -->
 <table cellpadding=0 cellspacing=0 border=0 bgcolor="#BCBCBC" width=100% height=101 background="entity/bck.gif" style='border-bottom:solid 2px <?php echo $colore_pannello;?>;'><tr>
 <td width=99% class='logo' height=100% style='padding-left:4px;padding-top:4px;'>
  <table cellpadding=0 cellspacing=0 border=0 width=99% height=100%><tr>
  <td height=50% class="logo" style='color:#000000;font-weight:normal;padding-bottom:7px;' valign=bottom>:: Pannello di Controllo ::</td>
  <td valign=bottom class='creditV' align=right style='padding-right:3px;'>Benvenuto: <b><?php echo getDati("Tool","USER",$_SESSION['user']);?></b></td>
 </tr><tr>
  <td colspan=2 height=50% style='border-top:solid 1px <?php echo $colore_pannello;?>;border-right:solid 1px <?php echo $colore_pannello;?>;padding-bottom:25px;' valign=bottom align=right>
  <span class="logo" style='padding-bottom:3px;font-variant:small-caps;padding-left:10px;line-height:16px;font-weight:normal;letter-spacing:1px;color:<?php echo $colore_pannello;?>;'>:: <?=$nome_dominio;?> :: &nbsp;</span>
  </td>
 </tr></table>
 </td>
 <td width=1% style='padding-right:3px;'><img src="entity/img.jpg" vspace=0 hspace=0></td>
 </tr></table>
<!-- TOP BODY END --></td>
</tr><tr>
<td height=99%><!-- MIDDLE BODY START -->
<DIV class='testo' id='tool' style='height:100%;width:100%;margin:4px;background-color:#ffffff;'>
INSERISCI I VINI


<FORM name="Inserisci" action="vini_add.php" method="post" enctype="multipart/form-data">
<span class="label">Tipologia</span><br>
<SELECT name="tipo" class="form"><OPTION value=''>Scegli tipologia</OPTION><?
  $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
  if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
  $query = "SELECT ID,NOME FROM Vini_categorie ORDER BY NOME ASC";
  $result = mysql_query($query,$db);
  while ($riga = mysql_fetch_array($result)) {
   echo "<OPTION value=\"".$riga[ID]."\">".stripslashes($riga[NOME])."</OPTION>";
 }
 mysql_close($db);
 ?></SELECT><br>
<span class="label">Cantina</span><br>
<!-- SELECT name="cantina" class="form"><OPTION value=''>Scegli cantina</OPTION><?
  $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
  if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
  $query = "SELECT ID,NOME FROM Cantine ORDER BY NOME ASC";
  $result = mysql_query($query,$db);
  while ($riga = mysql_fetch_array($result)) {
   echo "<OPTION value=\"".$riga[ID]."\">".stripslashes($riga[NOME])."</OPTION>";
 }
 mysql_close($db);
 ?></SELECT -->
 <input type="text" name="cantina_nome" class="form" size="30"><br>
 <br>
<span class="label">Regione</span><br>
<SELECT name="regione" class="form"><OPTION value=''>Scegli regione</OPTION><?
  $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
  if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
  $query = "SELECT ID,nome FROM Regioni ORDER BY nome ASC";
  $result = mysql_query($query,$db);
  while ($riga = mysql_fetch_array($result)) {
   echo "<OPTION value=\"".$riga[ID]."\">".stripslashes($riga[nome])."</OPTION>";
 }
 mysql_close($db);
 ?></SELECT><br>
<span class="label">Nome</span><br>
<input type="text" name="nome" class="form" size="30"><br>
<span class="label">Uvaggio</span><br>
<input type="text" name="uvaggio" class="form" size="30"><br>
<span class="label">Grado</span><br>
<input type="text" name="grado" class="form" size="4"><br>
<span class="label">Capacita</span><br>
<input type="text" name="capacita" class="form" size="10"><br>
<span class="label">Descrizione</span><br>
<textarea style="width: 400px; height: 100px;" id="descrizione" name="descrizione"></textarea>
<script type="text/javascript" src="../js/nicEdit.js"></script>
<script type="text/javascript">
new nicEditor({iconsPath : '../js/nicEditorIcons.gif'}).panelInstance('descrizione');
</script>
<span class="label">Immagine Vino</span><br>
<input type="file" name="image" class="form" size="20"><br>
<span class="label">Immagine Etichetta</span><br>
<input type="file" name="etichetta" class="form" size="20"><br>
<span class="label">Prezzo al pubblico (calice)</span><br>
<input type="text" name="prezzo_calice" class="form" size="10"><br>
<span class="label">Prezzo al pubblico (bottiglia)</span><br>
<input type="text" name="prezzo_pubbl" class="form" size="10"><br>
<span class="label">Prezzo al pubblico (asporto)</span><br>
<input type="text" name="prezzo_asp" class="form" size="10"><br>
<span class="label">Prezzo acquisto</span><br>
<input type="text" name="prezzo_legiare" class="form" size="10"><br>
<span class="label">Ordine</span><br>
<input type="text" name="ordine" class="form" size="10"><br>
<input type="submit" name="pulsante" class="form" value="Inserisci">
</FORM>




</DIV><!-- MIDDLE BODY START --></td>
</tr></table>
 </TD>
</TR><TR>
 <TD HEIGHT=1% COLSPAN=2 align=center bgcolor="#BCBCBC" class='testo' style='padding-top:6px;padding-bottom:2px;border-top:solid 3px <?php echo $colore_pannello;?>'>
 Copyright 2008 :: <?=$nome_dominio;?> :--: Created by <a href="http://www.i-factory.biz/" target=new class="testo">i-F@ctory</a> &#149; Control Panel ver. 1.0</TD>
</TR></TABLE>
</BODY>
</HTML>
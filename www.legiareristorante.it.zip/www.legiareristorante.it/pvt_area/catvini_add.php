<?php
session_start();
include_once("../includes/libreria.php");
include("../includes/conf.php");
If (($_SESSION['IsUserGood'] == False) || (!isset($_SESSION['user']))) {
	header("location: ../tool.php?ctrl=2"); 
}

if ($_POST[pulsante]=="Inserisci") {
 $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
 if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
 $query = "INSERT INTO Vini_categorie (NOME) values ('".addslashes(strip_tags($_POST['nome']))."')";
 if (mysql_query($query,$db)) {
 	echo "<script>alert('Categoria Vini Inserita Correttamente')</script>";
 }
 else {
 	echo "<script>alert('Errore nell'inserimento della Categoria Vini')</script>";
 }
 mysql_close($db);
}

?>
<html>
<head>
<title><?=$nome_dominio;?> :: Pannello di Controllo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="Author" content="I-Factory di Nicola Claudio Cellamare">
<META NAME="robots" CONTENT="index, follow"> <!-- (Robot commands: All, None, Index, No Index, Follow, No Follow) -->
<META NAME="revisit-after" CONTENT="2 days">
<META NAME="distribution" CONTENT="global">
<META NAME="rating" CONTENT="general">
<META NAME="Content-Language" CONTENT="italiano">
<LINK href="../includes/tool.css" rel=STYLESHEET type=text/css>
<SCRIPT language=Javascript><!-- 
function mon(str) {
 window.status = str
}
function mout() {
 window.status = "Pannello di Controllo :: <?=$nome_dominio;?>"
}

//-->
</SCRIPT>

</head>
<BODY BGCOLOR="#FFFFFF" LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0 onLoad="mout();">
<TABLE CELLPADDING=0 CELLSPACING=1 BORDER=0 WIDTH=100% HEIGHT=100%><TR>
<TD WIDTH=1% HEIGHT=99% VALIGN=TOP style="border-right:solid 1px <?php echo $colore_pannello;?>">
<!-- TABELLA TOP START -->
 <table cellpadding=0 cellspacing=0 border=0 height='60' width='176' style="border-bottom:solid 1px <?php echo $colore_pannello;?>"><tr>
  <td width=180 align=center><a href="index.php"><img src="entity/<?=$logo;?>" border=0 Alt="<?=$nome_dominio;?> :: Home Pannello di controllo"></a></td>
</tr></table>
<!-- TABELLA TOP END -->
<!-- MENU' START -->
 <table cellpadding=0 cellspacing=0 border=0 width=170><tr>
 <td><!-- MENU' START --><script language="JavaScript" type="text/javascript" src="../includes/menu.js"></script>
  <?php include("menu.php")?>
    <DIV id="liveclock" class="credit" style='color:#aaaaaa;margin-left:8px;margin-top:10px;font-size:9px;'><!-- OROLOGIO - START --><script type='text/javascript' src="../includes/orologio.js"></script><!-- OROLOGIO - END --></DIV></td>
 </tr></table>
<!-- MENU' END -->
</TD>
 <TD WIDTH=99% HEIGHT="99%" VALIGN=TOP>
<table cellpadding=0 cellspacing=0 border=0 width=100% height=100%><tr>
<td height=1%><!-- TOP BODY START -->
 <table cellpadding=0 cellspacing=0 border=0 bgcolor="#BCBCBC" width=100% height=101 background="entity/bck.gif" style='border-bottom:solid 2px <?php echo $colore_pannello;?>;'><tr>
 <td width=99% class='logo' height=100% style='padding-left:4px;padding-top:4px;'>
  <table cellpadding=0 cellspacing=0 border=0 width=99% height=100%><tr>
  <td height=50% class="logo" style='color:#000000;font-weight:normal;padding-bottom:7px;' valign=bottom>:: Pannello di Controllo ::</td>
  <td valign=bottom class='creditV' align=right style='padding-right:3px;'>Benvenuto: <b><?php echo getDati("Tool","USER",$_SESSION['user']);?></b></td>
 </tr><tr>
  <td colspan=2 height=50% style='border-top:solid 1px <?php echo $colore_pannello;?>;border-right:solid 1px <?php echo $colore_pannello;?>;padding-bottom:25px;' valign=bottom align=right>
  <span class="logo" style='padding-bottom:3px;font-variant:small-caps;padding-left:10px;line-height:16px;font-weight:normal;letter-spacing:1px;color:<?php echo $colore_pannello;?>;'>:: <?=$nome_dominio;?> :: &nbsp;</span>
  </td>
 </tr></table>
 </td>
 <td width=1% style='padding-right:3px;'><img src="entity/img.jpg" vspace=0 hspace=0></td>
 </tr></table>
<!-- TOP BODY END --></td>
</tr><tr>
<td height=99%><!-- MIDDLE BODY START -->
<DIV class='testo' id='tool' style='height:100%;width:100%;margin:4px;background-color:#ffffff;'>
INSERISCI E MODIFICA LE CATEGORIE VINI


<FORM name="Inserisci" action="catvini_add.php" method="post" enctype="multipart/form-data">
<span class="label">Nome</span><br>
<input type="text" name="nome" class="form" size="30"><br>
<input type="submit" name="pulsante" class="form" value="Inserisci">
</FORM>


<span class="titoloTool">Modifica Categorie</span><br>
<iframe id="modifica" style="width:100%;height:200px;" frameborder=0 src="catvini_mod.php" border=1></iframe>



</DIV><!-- MIDDLE BODY START --></td>
</tr></table>
 </TD>
</TR><TR>
 <TD HEIGHT=1% COLSPAN=2 align=center bgcolor="#BCBCBC" class='testo' style='padding-top:6px;padding-bottom:2px;border-top:solid 3px <?php echo $colore_pannello;?>'>
 Copyright 2008 :: <?=$nome_dominio;?> :--: Created by <a href="http://www.i-factory.biz/" target=new class="testo">i-F@ctory</a> &#149; Control Panel ver. 1.0</TD>
</TR></TABLE>
</BODY>
</HTML>
<?php
include_once("includes/db.php");
include_once("includes/conf.php");
session_start();

if (!empty($_POST['user'])) {
$db = mysql_connect($db_host, $db_user, $db_pass);
if ($db==False)die("Errore nella connessione");
if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
// replace per MySql Injection
$user = str_replace("'","",$_POST['user']);
$pass = str_replace("'","",$_POST['psw']);
echo $user;
echo $pass;
$query = "SELECT ID FROM Tool WHERE USER='".$user."' AND PSW='".$pass."'";
$result = mysql_query($query,$db);
 if (mysql_num_rows($result)==1){
    $row = mysql_fetch_array($result);
    $_SESSION['user'] = $row['ID'];
    $_SESSION['IsUserGood'] = 'True';
    //print $_SESSION['user'];
    
    header("location: pvt_area/index.php"); 
 }else {
    header("location: tool.php?ctrl=1"); 
 }
 mysql_close($db);
}

?>
<html>
<head>
<title><?=$nome_dominio;?> :: Pannello di Controllo</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta name="keywords" content="">
<meta name="description" content="">
<meta name="Author" content="I-Factory di Nicola Claudio Cellamare">
<META NAME="robots" CONTENT="index, follow"> <!-- (Robot commands: All, None, Index, No Index, Follow, No Follow) -->
<META NAME="revisit-after" CONTENT="2 days">
<META NAME="distribution" CONTENT="global">
<META NAME="rating" CONTENT="general">
<META NAME="Content-Language" CONTENT="italiano">
<LINK href="includes/tool.css" rel=STYLESHEET type=text/css>
<SCRIPT language=Javascript><!-- 
function mon(str) {
 window.status = str
}
function mout() {
 window.status = "Pannello di Controllo :: <?=$nome_dominio;?>"
}

function chkvals() {
 var warn = ""
 ret_val = true
   if (document.forms['Accedi'].user.value.length <= 0) warn += " Login mancante\r"
   if (document.forms['Accedi'].psw.value.length <= 0) warn += " Password mancante\r"
 if (warn.length >= 1) {
  alert_str = warn
  alert(alert_str)
  ret_val = false
  //alert(ret_val)
 }
 return ret_val
 alert(ret_val)
}
//-->
</SCRIPT>

</head>
<BODY BGCOLOR="#FFFFFF" LEFTMARGIN=0 TOPMARGIN=0 MARGINWIDTH=0 MARGINHEIGHT=0 onLoad="mout();">
<TABLE CELLPADDING=0 CELLSPACING=0 BORDER=0 WIDTH=100% HEIGHT=400><TR>
<TD height=48 valign=top background="pvt_area/entity/top_body_bg.jpg" style="background-repeat:no-repeat;background-position:top right;">
 <table cellpadding=0 cellspacing=0 border=0 width=100% height=47><tr>
  <td class='TitSezione' style='color:#000000;font-size:18px;font-variant:normal;padding-left:10px;letter-spacing:1px;'>Pannello di Controllo</td>
  <td class='credit' align=center style='color:#ffffff;'>&copy Copyright 2008  <a href="http://www.i-factory.biz/" target=new class='credit'>I-factory</a><br>All rights reserved</td>
 </tr></table>
</TD>
</TR><TR>
 <TD height=2 bgcolor="<?=$colore_pannello;?>"></TD>
</TR><TR>
 <TD height=350 align=center>
  <form name='Accedi' method='post' action='tool.php' onSubmit="return chkvals()">
  <table cellpadding=0 cellspacing=0 border=0 width=453 style="border-style:solid;border-color:<?=$colore_pannello;?>;border-width:1px;"><tr>
   <td height=59 background="pvt_area/entity/bck_tool.gif" style="border-bottom:solid 1px; #006599;background-repeat:no-repeat;padding-left:70px;font-size:16px;letter-spacing:1px;" class='TitSezione'>Login a <?=$nome_dominio;?> Tool v. 1.0</td>
  </tr><tr>
   <td align=center style='padding-top:6px;'><table cellpadding=0 cellspacing=0 border=0 width=80%><tr>
     <td colspan=2 class='credit' height=50 style='font-size:11px;color:#000000;'>Inserire il nome login nel campo "Login" e la password nel campo "Password".<br>Quindi cliccate su "Login".</td>
    </tr><tr>
     <td class='credit' height=20 style='font-size:11px;color:#000000;'>Login</td>
     <td><input type='text' name='user' class='form' size=15></td>
    </tr><tr>
     <td class='credit' height=30 style='font-size:11px;color:#000000;'>Password</td>
     <td><input type='password' name='psw' class='form' size=15></td>
    </tr><tr>
     <td height=30>&nbsp;</td>
     <td colspan=2 align=left style='padding-right:8px;'><input type=submit name='pulsante' class='form' value='Login'></td>
    </tr></table>
   </form>
<?
if ($_GET[ctrl] == 1) {
 echo "<div class='TitSezione' style='color:#2CA44B;margin-bottom:10px;margin-top:-10px;'>Utente non esistente</div>";
}
if ($_GET[ctrl] == 2) {
 echo "<div class='testo' style='color:#2CA44B;margin-bottom:10px;margin-top:-10px;'>Sessione utente terminata per inattivit�...<br>Loggarsi nuovamente</div>";
}
// Se l'utente clicca su LogOut svuoto le variabili di sessione
if ($_GET["ctrl"] == 3) {
 $_SESSION["IsUserGood"] = null;
 $_SESSION["user"] = null;
 $_SESSION["type"] = null;
}
?>   
   </td>
  </tr></table>
 <a href="http://www.i-factory.biz" target=new><img src="pvt_area/entity/i-factory.jpg" border=0 alt="I-factory.biz" hspace=10 vspace=4></a>
 <a href="http://www.oddepisodes.com" target=new><img src="pvt_area/entity/oddepisodes.jpg" border=0 alt="OddEpisodes" vspace=4></a>
 </TD>
</TR></TABLE>
</BODY>
</HTML>
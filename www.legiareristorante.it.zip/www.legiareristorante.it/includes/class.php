<?php

// Classe per lo sviluppo di oggetti IMAGE - START
class IMAGE {
       
    
	function Upload ($dir_foto, $nome_file, $nome_filetemp) {
    	//$peso � la dimensione massima consentita per file in byte 1024 byte = 1 Kb
	//$dimensione_massima_Kb=$peso/1024;
	$cartella_upload=$dir_foto.'/'; //cartella in cui eseguire l'upload (controllare permessi scrittura)
	$filtrare=1; //filtrare x estensioni ammesse? 1=si 0=no
	$array_estensioni_ammesse=array('.jpg','.gif','.png'); //estensioni ammesse
	/* upload img */
		if($filtrare==1){
			$estensione = strtolower(substr($nome_file, strrpos($nome_file, "."), strlen($nome_file)-strrpos($nome_file, ".")));
			if(!in_array($estensione,$array_estensioni_ammesse)){
				print "<p class=label>Errore.2: Upload Immagine non ammesso a causa della sua estensione. Estensioni ammesse: ".implode(", ",$array_estensioni_ammesse)."</p>";
				}
			}
		if(!file_exists($cartella_upload)){
			print "<p class=label>Errore.3: La cartella di destinazione per l'upload dell'immagine non esiste.</p>";
			}
		if(is_uploaded_file($nome_filetemp)) {
			
		$nome_file = str_replace(" ", "", $nome_file);
		$nome_file = str_replace("_", "", $nome_file);
		
		if(move_uploaded_file($nome_filetemp, $cartella_upload.$nome_file)){
				chmod($cartella_upload.$nome_file,0777); //permessi per poterci sovrascrivere/scaricare
				//echo "<p class=label>Upload Immagine riuscito in maniera corretta.</p>";
				} else {
					echo "<p class=label>Errore.4: Upload Immagine non effettuato.</p>";
					}
		} else {
			echo "<p class=label>Errore.5: Problemi con l'upload del file.</p>";
			}
		/* end upload img */
		$wtmk = "../entity/giare.png";
		$src_filename = $cartella_upload.$nome_file;
		$srcThumbs_filename = $cartella_upload.'s_'.$nome_file;
		list($src_width,$src_height,$src_type,$src_attr) = getimagesize($src_filename);
		list($wtmk_width,$wtmk_height,$wtmk_type,$wtmk_attr) = getimagesize($wtmk);
		$src_width2=$src_width;
		$src_height2=$src_height;
		$dest_width=400;;
		$dest_width2=100;
		
		
		if($src_width > $dest_width2) {
		//inizio il resize
		switch($src_type){
				case 1:
				$src_image =imagecreatefromgif($src_filename);
				break; 
            			case 2: 
		                $src_image =imagecreatefromjpeg($src_filename);
		                break; 
			        case 3: 
		                $src_image =imagecreatefrompng($src_filename);
		                break; 
		                default:    ;//return false;
		                }
		if(!($src_image==0)){
			
			
			
			//salvo l'immagine con larghezza 100 
       			$quality = '100';
       			
       			
       			if($src_width > $src_height) {
$x = ceil(($src_width - $src_height) / 2 );
$src_width2 = $src_height;
} else if($src_height > $src_width) {
$y = ceil(($src_height - $src_width) / 2);
$src_height2 = $src_width;
}
$dest_image = imagecreatetruecolor($dest_width2,$dest_width2);
imagecopyresampled($dest_image, $src_image, 0, 0, $x, $y, $dest_width2, $dest_width2, $src_width2, $src_height2);
imagejpeg($dest_image, $srcThumbs_filename, $quality);
chmod($srcThumbs_filename,0777); //permessi per poterci sovrascrivere/scaricare


} else {
	       			echo "<p class=label>Errore.7: Problemi con il resize del file.</p>";
	       			}
		//end resize
	}
	
	if($src_width > $dest_width) {
		//inizio il resize
		switch($src_type){
				case 1:
				$src_image =imagecreatefromgif($src_filename);
				break; 
            			case 2: 
		                $src_image =imagecreatefromjpeg($src_filename);
		                break; 
			        case 3: 
		                $src_image =imagecreatefrompng($src_filename);
		                break; 
		                default:    ;//return false;
		                }
		if(!($src_image==0)){
			switch($wtmk_type){
				case 1:
				$wtmk_image =imagecreatefromgif($wtmk);
				break; 
            			case 2: 
		                $wtmk_image =imagecreatefromjpeg($wtmk);
		                break; 
			        case 3: 
		                $wtmk_image =imagecreatefrompng($wtmk);
		                break; 
		                default:    ;//return false;
		                }
		        if(!($wtmk_image==0)){
			//salvo l'immagine con larghezza 600 lasciandola proporzionata 
       			$quality = '100';
		        $ratio = $src_width / $dest_width;
		        $dest_image = imagecreatetruecolor($dest_width, $src_height / $ratio); 
		        imagecopyresampled($dest_image, $src_image, 0, 0, 0, 0, $src_width / $ratio, $src_height / $ratio, $src_width, $src_height); 
		        imagejpeg($dest_image, $src_filename, $quality);
		        chmod($src_filename,0777); //permessi per poterci sovrascrivere/scaricare
		        list($newsrc_width,$newsrc_height,$newsrc_type,$newsrc_attr) = getimagesize($src_filename);
switch($newsrc_type){
				case 1:
				$newsrc_image =imagecreatefromgif($src_filename);
				break; 
            			case 2: 
		                $newsrc_image =imagecreatefromjpeg($src_filename);
		                break; 
			        case 3: 
		                $newsrc_image =imagecreatefrompng($src_filename);
		                break; 
		                default:    ;//return false;
		                }
if(!($newsrc_image==0)){
$width = (($newsrc_width - $wtmk_width)/2);
$height = (($newsrc_height - $wtmk_height)/2);

//creiamo un immagine che comprenda il sorgente modificato e il suo watermark 
@imagecopy($newsrc_image,$wtmk_image,0,0,0,0,$wtmk_width,$wtmk_height);
imagejpeg($newsrc_image, $src_filename, $quality);
chmod($src_filename,0777); //permessi per poterci sovrascrivere/scaricare

}
		        }
		        } else {
	       			echo "<p class=label>Errore.6: Problemi con il resize del file.</p>";
	       			}
		//end resize
		} else {
			// se non fa il resize applico solo il wtmk
			
			switch($wtmk_type){
				case 1:
				$wtmk_image =imagecreatefromgif($wtmk);
				break; 
            			case 2: 
		                $wtmk_image =imagecreatefromjpeg($wtmk);
		                break; 
			        case 3: 
		                $wtmk_image =imagecreatefrompng($wtmk);
		                break; 
		                default:    ;//return false;
		                }
		        if(!($wtmk_image==0)){
       			$quality = '100';
		    switch($src_type){
				case 1:
				$src_image =imagecreatefromgif($src_filename);
				break; 
            			case 2: 
		                $src_image =imagecreatefromjpeg($src_filename);
		                break; 
			        case 3: 
		                $src_image =imagecreatefrompng($src_filename);
		                break; 
		                default:    ;//return false;
		                }
if(!($src_image==0)){
$width = (($src_width - $wtmk_width)/2);
$height = (($src_height - $wtmk_height)/2);

//creiamo un immagine che comprenda il sorgente modificato e il suo watermark 
@imagecopy($src_image,$wtmk_image,0,0,0,0,$wtmk_width,$wtmk_height);
imagejpeg($src_image, $src_filename, $quality);
chmod($src_filename,0777); //permessi per poterci sovrascrivere/scaricare

}
		        }
		        else {
	       			echo "<p class=label>Errore.6: Problemi con il resize del file.</p>";
	       			}
			
		}
	
	}
	
}
?>

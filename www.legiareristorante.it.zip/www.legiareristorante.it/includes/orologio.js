gg = new Array("Domenica","Luned�","Marted�","Mercoled�","Gioved�","Venerd�","Sabato"); 
function visua() 
   { 
   var ora = new Date(); 
   var aa = ora.getDate(); 
   var mm = ora.getMonth() + 1; 
   var yy = ora.getYear(); 
   var oo = ora.getHours(); 
   var mn = ora.getMinutes(); 
   var sec = ora.getSeconds(); 
   var dd = ora.getDay(); 
   var aa2  = ((aa < 10) ? "0" : ""); 
   var mm2  = ((mm < 10) ? "/0" : "/"); 
   var oo2  = ((oo < 10) ? "0" : ""); 
   var mn2  = ((mn < 10) ? ":0" : ":"); 
   var sec2  = ((sec < 10) ? ":0" : ":"); 
   var Data = aa2 + aa + mm2 + mm  + "/" + yy; 
   var hh = oo2 + oo + mn2 + mn + sec2 + sec; 
   if(document.all) 
      document.all.liveclock.innerHTML = gg[dd] + ", " + Data + ", " + hh; 
   else 
      if(document.getElementById) 
         document.getElementById('liveclock').innerHTML  = gg[dd] + ", " + Data + ", " + hh; 
   window.setTimeout("visua()",1000); 
   } 
onload=visua; mout();
<?
	$db_host = "62.149.150.90";
	$db_name = "Sql245889_1";
	$db_user = "Sql245889";
	$db_pass = "4ca39e3d";
?>

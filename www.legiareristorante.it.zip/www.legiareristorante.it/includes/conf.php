<?php

$logo = "logo.jpg";
$nome_dominio = "Le Giare Ristorante";
$colore_pannello = "#622020"; // Linee e colore men�


?>
﻿<?php
include_once("includes/libreria.php");
include("includes/conf.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Le Giare | ristorante</title>
<!-- base href="http://www.legiareristorante.it" -->
<meta name="description" content=""> 
<meta name="keywords" content=""> 
<meta name="Author" content="Oddep - creactivetions Bari (Italy) - I-Factory web agency">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name-equiv="Content-Language" CONTENT="IT">
<meta name="distribution" CONTENT="Global">
<meta name="revisit-after" CONTENT="5 days">
<!--<meta http-equiv="refresh" content="120">-->
<meta name="robots" CONTENT="FOLLOW,INDEX">
<link rel="icon" href="" type="image/x-icon" />
<link rel="shortcut icon" href="" type="image/x-icon" />
<link rel="stylesheet" type="text/css" href="style.css">
<script type="text/javascript" src="js/prototype.js"></script>
<script type="text/javascript" src="js/scriptaculous.js?load=effects"></script>
<script type="text/javascript" src="js/lightbox.js"></script>
<link rel="stylesheet" href="lightbox.css" type="text/css" media="screen" />
<SCRIPT language=Javascript><!--
function mon(str) {
 window.status = str
}
function mout() {
 window.status = "Le Giare | ristorante"
}
//-->
</SCRIPT>
<?php include("analytics.php")?>
</head>
<BODY onLoad="mout();">
 <!-- start header -->
 <div id="header">
  <!--start logo -->
  <div id="logo">
   <a href="index.php"><img src="entity/s_logo.gif" border="0" alt="torna alla home page"></a>
  </div>
  <!-- end logo -->
  <!-- start foto header -->
  <div id="foto_header">
   <img src="entity/foto_02.jpg" alt="Le Giare ristorante">
  </div>
  <!-- end foto header -->
  <div class="clear"></div>
 </div>
 
 
 <div id="main">
  <!-- start col sx -->
  <?php include("menuLeft.php");?>
  
  <!-- end col sx -->
  <!-- start col dx -->
  <div id="colDX">
  <div style="width:500px;">
   <p style="font-size: 12px; line-height: 16px;">
    <? echo stripslashes(strip_tags(getDati("Testi","valore",3),'<br><a><em>'));?>
   </p>
   </div>
   <!-- START MENU PASQUA -->
<h2 style="color: #000; font-size: 16px">Le Giare sospende per le ferie estive la cucina e, volendo bere, le bottiglie da ASPORTO sono sempre disponibili, col loro appassionato propositore... <em>Massimo Fiorentino in Bari</em></h2>
<!--   
   <h2 style="color: #000; font-size: 16px"> Menù di Pasqua 2013</h2>
   <p style="font-size: 14px;"> Di seguito le portate previste per la giornata di Pasqua - 31 Marzo 2013</p>
   <ul style="list-style-type: square; font-size: 13px; margin-bottom: 10px;">
   <li> Focaccia di grano arso in versione "pasquale"</li>
   <li> Ricotta fritta e agretti con bavarese d'agnello e campari orange</li>
   <li> Terrina di piccione e zucca con salsa al profumo di liquirizia</li>
   <li> Caramelle di sfoglia fresca ripiene con mousse di piselli, pancetta.. di Martina Franca e uovo pochè al fior di lavanda</li>
   <li> Secreto di suino iberico in salsa di lime e peperoncino con croquette.. di patate e fichi</li>
   <li> Mimosa di ricotta agli agrumi con biscotto al caffé</li>
   </ul>
   <p style="font-size: 14px; font-weight: bold;">Euro 60 (vini esclusi)</p> 
   -->   
   <!-- FINE MENU PASQUA -->

   <p style='text-align:right;margin-bottom:20px;'></p>
   <?
   $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
   if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
    	$query = "SELECT * FROM Eventi WHERE TIPOLOGIA=1 AND HOME=1 ORDER BY ID DESC LIMIT 0,2";
    	$result = mysql_query($query,$db);
    	$num_prodotti = mysql_num_rows($result);
    	if ($num_prodotti!=0){
    		echo "<h1 class=\"eventi\" style='margin-top: 40px;'><span>Eventi</span></h1>";
    		while ($riga = mysql_fetch_array($result)) {
    			if ($riga[DATA]!='') {echo "<p><i>".$riga[DATA]; if ($riga[ORARIO]!='') {echo " - ".$riga[ORARIO]."</i></p>";} else { echo "</i></p>"; }}
    			if ($riga[TITOLO]!='') {echo "<h2 style='color:#333333;margin-bottom:5px;margin-top:0px;padding:0px;'>".stripslashes(ucfirst($riga[TITOLO]))."</h2>";}
    			if ($riga[DESCR]!='') {echo "<p>".stripslashes($riga[DESCR])."</p>";}
    			
    			echo "<p style='text-align:right;margin-bottom:40px;'></p>";
                        echo "<div class='clear'></div>";
    			}   			
    		}
   ?>

   <?
   $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
   if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
    	$query = "SELECT * FROM Eventi WHERE TIPOLOGIA=2 AND HOME=1 ORDER BY ID DESC";
    	$result = mysql_query($query,$db);
    	$num_prodotti = mysql_num_rows($result);
    	if ($num_prodotti!=0){
    		echo '<h1 class="news" style="margin-bottom: -5px;"><span>News</span></h1>';
    		while ($riga = mysql_fetch_array($result)) {
    			if ($riga[DATA]!='') {echo "<p><i>".$riga[DATA]; if ($riga[ORARIO]!='') {echo " - ".$riga[ORARIO]."</i></p>";} else { echo "</i></p>"; }}
    			if ($riga[TITOLO]!='') {echo "<h2 style='color:#333333;margin-bottom:5px;margin-top:0px;padding:0px;'>".stripslashes(ucfirst($riga[TITOLO]))."</h2>";}
    			if ($riga[DESCR]!='') {echo "<p>".stripslashes($riga[DESCR])."</p>";}

    			echo "<p style='text-align:right;margin-bottom:40px;'></p>";
                        echo "<div class='clear'></div>";
    			}
    		}
   ?>

   <?
   $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
   if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
    	$query = "SELECT * FROM Eventi WHERE TIPOLOGIA=3 AND HOME=1 ORDER BY ID DESC";
    	$result = mysql_query($query,$db);
    	$num_prodotti = mysql_num_rows($result);
    	if ($num_prodotti!=0){
    		echo '<h1 class="dicono" style="margin-bottom: 5px;"><span>Dicono di noi</span></h1>';
    		while ($riga = mysql_fetch_array($result)) {
    			if ($riga[DATA]!='') {echo "<p><i>".$riga[DATA]; if ($riga[ORARIO]!='') {echo " - ".$riga[ORARIO]."</i></p>";} else { echo "</i></p>"; }}
    			if ($riga[TITOLO]!='') {echo "<h2 style='color:#333333;margin-bottom:5px;margin-top:0px;padding:0px;'>".stripslashes(ucfirst($riga[TITOLO]))."</h2>";}
    			if ($riga[DESCR]!='') {echo "<p>".stripslashes($riga[DESCR])."</p>";}

    			echo "<p style='text-align:right;margin-bottom:40px;'></p>";
                        echo "<div class='clear'></div>";
    			}
    		}
   ?>


  </div>
  <!-- end col dx -->
  <div class="clear"></div>
 </div>
 <!-- end main -->
 <!-- start footer -->
 <div id="footer">
  <div id="dati" style="text-align:center;"><span class="ris">Le Giare, ristorante</span> | Corso Alcide De Gasperi, 308 F - 70125 Bari (Italy)</div>
  <div id="menuBOTTOM" style="text-align:center;margin-top:10px;"><a href="index.php">le giare</a> | <a href="menu.php">men&ugrave;</a> | <a href="cartavini.php">carta dei vini</a> | <a href="dovesiamo.php">dove siamo</a> | <a href="contatti.php">contatti</a> | <a href="http://www.oddepisodes.com">OddEp * creactivetions</a> | <a href="http://www.i-factory.biz">I-Factory - web agency</a></div>
 </div>
 <!-- end footer -->
</BODY>
</HTML>

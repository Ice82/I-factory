<!--
<div class="boxSX">
    <h3>Foto del ristorante</h3>
   <?
   $db = mysql_connect($db_host, $db_user, $db_pass) or die("Non riesco a connettermi al server <b>$db_host");
   if (!mysql_select_db($db_name,$db)) die ("Errore nella selezione del db");
    	$query = "SELECT * FROM Galleria WHERE HOME=1 ORDER BY ordine ASC";
    	$result = mysql_query($query,$db);
    	$num_prodotti = mysql_num_rows($result);
    	if ($num_prodotti!=0){
            while ($riga = mysql_fetch_array($result)) {
                echo '<a href="/galleria/'.$riga['file'].'" rel="lightbox[legiare]" title="'.$riga['descrizione'].'">
                            <img src="/galleria/'.str_replace("_","",$riga['fileS']).'" alt="'.$riga['descrizione'].'" border="0" class="littleFOTO">
                      </a>';
            }
        }
   ?>
    <div class="clear"></div>
    <br />
    <a href="/galleria-fotografica.php" style="font-size: 10px; color: #999; text-decoration: none;">galleria fotografica &raquo</a>
<!--
    <a href="/entity/galleryweb/legiare1.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare1.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare2.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare2.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare3.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare3.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare4.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare4.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare5.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare5.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare6.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare6.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare7.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare7.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare8.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare8.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare9.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare9.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare10.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare10.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare11.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare11.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare12.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare12.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare13.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare13.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare14.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare14.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare15.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare15.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare16.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare16.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare17.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare17.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>
    <a href="/entity/galleryweb/legiare18.jpg" rel="lightbox[legiare]"><img src="/entity/galleryweb/s_legiare18.jpg" alt="Le Giare ristorante" border="0" class="littleFOTO"></a>

</div>
-->